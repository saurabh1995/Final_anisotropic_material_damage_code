# Implicit Anisotropic Damage Model

`implicit_anisotropic_damage.py` implements a coupled plane-stress update for
viscoplasticity and directional damage. The in-plane Voigt order is
`[11, 22, 12]`; the full order is `[11, 22, 33, 23, 13, 12]`.

Run the included example from the package root:

```bash
python implicit_anisotropic/run_implicit_anisotropic.py
```
