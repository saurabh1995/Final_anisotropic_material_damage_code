#!/usr/bin/env python3
"""Run the self-contained CPU implicit anisotropic update on a small path."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

import implicit_anisotropic_damage as model


HERE = Path(__file__).resolve().parent
INPUT = HERE.parent / "inputs" / "strain43111.csv"
OUTPUT = HERE / "implicit_demo_summary.json"


def main() -> None:
    increment = np.genfromtxt(INPUT, delimiter=",").reshape(6)
    # A compact repeat count makes the packaged smoke test fast and deterministic.
    state, results = model.run_plane_stress_sequence(
        np.repeat(increment[None, :], 8, axis=0), scale=20.0, assume="increment"
    )
    output = {
        "input": str(INPUT.name),
        "steps": len(results),
        "status_counts": {
            "elastic": sum(r["status"] == "elastic" for r in results),
            "plastic": sum(r["status"] == "plastic" for r in results),
        },
        "final_sigma_voigt": model.stress_tens_to_voigt(state["stress_n"]).tolist(),
        "final_damage_diag": np.diag(state["D"]).tolist(),
        "final_eqplas": float(state["EQPLAS"]),
        "sigma33": float(state["stress_n"][2, 2]),
    }
    OUTPUT.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
