"""
Implicit anisotropic-damage constitutive update.

FE-facing core API:
- initialize_material_state(...)
- update_material_point(...)
- tangent_AD(...)

Standalone helper functions:
- run_viscoplastic_model_npz(...)
- run_plane_stress_sequence(...)
- run_and_save_default_strain_sequence(...)

The FE code will normally use only the core API and manage its own element,
integration-point, and load-step loops outside this module.
"""

import numpy as np
import torch
from torch.func import jacfwd


DTYPE = torch.float64


__all__ = [
    "DTYPE",
    "initialize_material_state",
    "update_material_point",
    "plane_stress_tangent_AD",
    "run_plane_stress_sequence",
    "repeat_increment_from_csv",
]


def props_update(E, pois):
    lam = (E * pois) / ((1.0 + pois) * (1.0 - 2.0 * pois))
    mu = 0.5 * E / (1.0 + pois)
    return lam, mu


def elastic_stiffness(E, pois):
    lam, mu = props_update(E, pois)
    aa = 2.0 * mu + lam
    C = np.array([
        [aa, lam, lam, 0.0, 0.0, 0.0],
        [lam, aa, lam, 0.0, 0.0, 0.0],
        [lam, lam, aa, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, mu, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, mu, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, mu],
    ], dtype=float)
    return C, lam, mu


def stress_tens_to_voigt(tens):
    # Voigt order: [11, 22, 33, 23, 13, 12]
    stress = np.zeros((6,), dtype=float)
    stress[0] = tens[0, 0]
    stress[1] = tens[1, 1]
    stress[2] = tens[2, 2]
    stress[3] = tens[1, 2]
    stress[4] = tens[0, 2]
    stress[5] = tens[0, 1]
    return stress


def stress_voigt_to_tens(voigt):
    # Voigt order: [11, 22, 33, 23, 13, 12]
    stress = np.zeros((3, 3), dtype=float)
    stress[0, 0] = voigt[0]
    stress[1, 1] = voigt[1]
    stress[2, 2] = voigt[2]
    stress[1, 2] = voigt[3]
    stress[2, 1] = voigt[3]
    stress[0, 2] = voigt[4]
    stress[2, 0] = voigt[4]
    stress[0, 1] = voigt[5]
    stress[1, 0] = voigt[5]
    return stress


def strain_tens_to_voigt(tens):
    # Voigt order: [11, 22, 33, 23, 13, 12] with engineering shear.
    strain = np.zeros((6,), dtype=float)
    strain[0] = tens[0, 0]
    strain[1] = tens[1, 1]
    strain[2] = tens[2, 2]
    strain[3] = 2.0 * tens[1, 2]
    strain[4] = 2.0 * tens[0, 2]
    strain[5] = 2.0 * tens[0, 1]
    return strain


def strain_voigt_to_tens(voigt):
    # Voigt order: [11, 22, 33, 23, 13, 12] with engineering shear.
    strain = np.zeros((3, 3), dtype=float)
    strain[0, 0] = voigt[0]
    strain[1, 1] = voigt[1]
    strain[2, 2] = voigt[2]
    strain[1, 2] = 0.5 * voigt[3]
    strain[2, 1] = 0.5 * voigt[3]
    strain[0, 2] = 0.5 * voigt[4]
    strain[2, 0] = 0.5 * voigt[4]
    strain[0, 1] = 0.5 * voigt[5]
    strain[1, 0] = 0.5 * voigt[5]
    return strain


def split(tens):
    ident = np.eye(3)
    arr = np.asarray(tens, dtype=float)
    shydro = arr.trace() / 3.0
    return arr - shydro * ident, shydro


def damage_scalar_mean(D, eps=1e-12):
    D = np.asarray(D, dtype=float)
    d = np.diag(D) if D.shape == (3, 3) else D.reshape(3)
    return float(np.clip(np.mean(d), 0.0, 1.0 - eps))


def damage_multiplier(D, eps=1e-12):
    D = np.asarray(D, dtype=float)
    d = np.diag(D) if D.shape == (3, 3) else D.reshape(3)
    d = np.clip(d, 0.0, 1.0 - eps)
    return np.diag(1.0 / np.sqrt(1.0 - d))


def damage_multiplier_inverse(D, eps=1e-12):
    D = np.asarray(D, dtype=float)
    d = np.diag(D) if D.shape == (3, 3) else D.reshape(3)
    d = np.clip(d, 0.0, 1.0 - eps)
    return np.diag(np.sqrt(1.0 - d))


def physical_to_effective(sigma, D):
    dev, hyd = split(sigma)
    H = damage_multiplier(D)
    D_H = damage_scalar_mean(D)
    sigma_dev = H @ dev @ H
    return sigma_dev + (hyd / (1.0 - D_H)) * np.eye(3)


def effective_to_physical(sigma, D):
    Hinv = damage_multiplier_inverse(D)
    D_H = damage_scalar_mean(D)
    ident = np.eye(3)

    B = Hinv @ sigma @ Hinv
    Hinv2 = Hinv @ Hinv

    p_phys = (1.0 - D_H) * np.trace(B) / (np.trace(Hinv2) + 1e-30)
    s_phys = Hinv @ (sigma - (p_phys / (1.0 - D_H + 1e-30)) * ident) @ Hinv
    return s_phys + p_phys * ident


def make_delta_eps(delta_eps6, eps33):
    de = np.asarray(delta_eps6, dtype=float).copy().reshape(6)
    de[2] = eps33
    return de


def initialize_material_state(
    pois=0.30,
    timeincrement=1e-6,
    N=8.15,
    E_default=113066.0,
    yield_default=180.0,
):
    C0, lam, mu = elastic_stiffness(E_default, pois)
    return {
        "timeincrement": timeincrement,
        "N": N,
        "E": E_default,
        "pois": pois,
        "lam": lam,
        "mu": mu,
        "stress_K": 11.45,
        "a_unit": 11000.0,
        "s_unit": 110.0,
        "a": 98939.30,
        "s": 1533.41,
        "stress_yield": yield_default,
        "D_cr": 0.22,
        "e_d": 0.0,
        "e_r": 0.16296296296296295,
        "C0": C0,
        "C_ep_ps": C0[np.ix_([0, 1, 5], [0, 1, 5])].copy(),
        "C_ep": C0.copy(),
        "stress_n": np.zeros((3, 3), dtype=float),
        "stress_back": np.zeros((3, 3), dtype=float),
        "eps_pl_tens": np.zeros((3, 3), dtype=float),
        "eps_el_tens": np.zeros((3, 3), dtype=float),
        "D": np.zeros((3, 3), dtype=float),
        "EQPLAS": 0.0,
        "Delta_pl": 0.0,
        "delta_eps": np.zeros((6,), dtype=float),
        "history_strain": [],
        "history_stress": [],
        "history_damage": [],
        "history_eqplas": [],
        "history_eps33": [],
    }


def stress_voigt_to_tens_t(v):
    # Voigt order: [11, 22, 33, 23, 13, 12]
    return torch.stack(
        (
            torch.stack((v[0], v[5], v[4])),
            torch.stack((v[5], v[1], v[3])),
            torch.stack((v[4], v[3], v[2])),
        )
    )


def stress_tens_to_voigt_t(T):
    # Voigt order: [11, 22, 33, 23, 13, 12]
    return torch.stack((T[0, 0], T[1, 1], T[2, 2], T[1, 2], T[0, 2], T[0, 1]))


def strain_voigt_to_tens_t(v):
    # Voigt order: [11, 22, 33, 23, 13, 12] with engineering shear.
    half = torch.tensor(0.5, dtype=v.dtype, device=v.device)
    return torch.stack(
        (
            torch.stack((v[0], half * v[5], half * v[4])),
            torch.stack((half * v[5], v[1], half * v[3])),
            torch.stack((half * v[4], half * v[3], v[2])),
        )
    )


def strain_tens_to_voigt_t(T):
    # Voigt order: [11, 22, 33, 23, 13, 12] with engineering shear.
    two = torch.tensor(2.0, dtype=T.dtype, device=T.device)
    return torch.stack((T[0, 0], T[1, 1], T[2, 2], two * T[1, 2], two * T[0, 2], two * T[0, 1]))


def dev_t(T):
    tr = torch.trace(T)
    return T - torch.eye(3, dtype=T.dtype, device=T.device) * (tr / 3.0)


def ddot(A, B):
    return torch.sum(A * B)


def split_t(T):
    hyd = torch.trace(T) / 3.0
    return dev_t(T), hyd


def diag_from_damage_vec_t(dvec):
    d = torch.clamp(dvec, min=0.0, max=0.99)
    return torch.diag(d)


def damage_scalar_mean_t(D):
    return torch.mean(torch.diag(D))


def damage_multiplier_t(D):
    d = torch.clamp(torch.diag(D), min=0.0, max=0.99)
    return torch.diag(1.0 / torch.sqrt(1.0 - d))


def damage_multiplier_inverse_t(D):
    d = torch.clamp(torch.diag(D), min=0.0, max=0.99)
    return torch.diag(torch.sqrt(1.0 - d))


def physical_to_effective_t(sigma, D):
    dev, hyd = split_t(sigma)
    H = damage_multiplier_t(D)
    D_H = damage_scalar_mean_t(D)
    return sigma_dev_t(H, dev) + (hyd / (1.0 - D_H + 1e-30)) * torch.eye(3, dtype=sigma.dtype, device=sigma.device)


def sigma_dev_t(H, dev):
    return H @ dev @ H


def effective_to_physical_t(sigma, D):
    Hinv = damage_multiplier_inverse_t(D)
    D_H = damage_scalar_mean_t(D)
    ident = torch.eye(3, dtype=sigma.dtype, device=sigma.device)

    B = Hinv @ sigma @ Hinv
    Hinv2 = Hinv @ Hinv

    p_phys = (1.0 - D_H) * torch.trace(B) / (torch.trace(Hinv2) + 1e-30)
    s_phys = Hinv @ (sigma - (p_phys / (1.0 - D_H + 1e-30)) * ident) @ Hinv
    return s_phys + p_phys * ident


def make_delta_eps_t(delta_eps6, eps33):
    e = delta_eps6.clone().to(DTYPE)
    e = e.clone()
    e[2] = eps33
    return e


def local_response_torch(xvec, delta_eps6, state_old_np, params_np):
    # Local unknown vector:
    # x = [eps33, dp, D1, D2, D3]
    #
    # Coupled five-unknown local solution and componentwise damage evolution.
    eps33 = xvec[0]
    dp = torch.clamp(xvec[1], min=1e-14)
    dvec = xvec[2:5]

    dt = torch.as_tensor(params_np["timeincrement"], dtype=DTYPE)
    C0 = torch.as_tensor(params_np["C0"], dtype=DTYPE)
    sigy = torch.as_tensor(params_np["stress_yield"], dtype=DTYPE)
    K = torch.as_tensor(params_np["stress_K"], dtype=DTYPE)
    Nrate = torch.as_tensor(params_np["N"], dtype=DTYPE)
    mu = torch.as_tensor(params_np["mu"], dtype=DTYPE)
    nu = torch.as_tensor(params_np["pois"], dtype=DTYPE)
    a_unit = torch.as_tensor(params_np["a_unit"], dtype=DTYPE)
    s_unit = torch.as_tensor(params_np["s_unit"], dtype=DTYPE)
    a = torch.as_tensor(params_np["a"], dtype=DTYPE)
    s = torch.as_tensor(params_np["s"], dtype=DTYPE)
    D_cr = torch.as_tensor(params_np["D_cr"], dtype=DTYPE)
    e_d = torch.as_tensor(params_np["e_d"], dtype=DTYPE)
    e_r = torch.as_tensor(params_np["e_r"], dtype=DTYPE)

    sigma_old_phys = torch.as_tensor(state_old_np["stress_n"], dtype=DTYPE)
    back_old_phys = torch.as_tensor(state_old_np["stress_back"], dtype=DTYPE)
    D_old = torch.as_tensor(state_old_np["D"], dtype=DTYPE)

    D_new = diag_from_damage_vec_t(dvec)
    delta_eps = make_delta_eps_t(delta_eps6, eps33)

    sigma_old_eff = physical_to_effective_t(sigma_old_phys, D_old)
    back_old_eff = physical_to_effective_t(back_old_phys, D_old)

    sig_eff_tr6 = stress_tens_to_voigt_t(sigma_old_eff) + C0 @ delta_eps
    sig_eff_tr = stress_voigt_to_tens_t(sig_eff_tr6)
    s_eff_tr = dev_t(sig_eff_tr)

    # Algebraic recovery weakens the shifted overstress state with delta_p.
    back_old_phys_pred = back_old_phys / (1.0 + s_unit * dp + 1e-30)
    back_old_eff_pred = physical_to_effective_t(back_old_phys_pred, D_old)
    zeta = s_eff_tr - back_old_eff_pred
    J = torch.sqrt(1.5 * ddot(zeta, zeta) + 1e-30)
    N_eff = zeta / J

    h = sigy + K * (dp / dt) ** (1.0 / Nrate)
    alpha = 1.0 + (3.0 * mu + (a_unit / (1.0 + s_unit * dp))) * (dp / h)
    R_vp = (J / alpha) - h

    N_phys = effective_to_physical_t(N_eff, D_new)
    dep_tens = 1.5 * dp * N_phys
    eps_pl_dot = dep_tens / dt

    dep_voigt = strain_tens_to_voigt_t(dep_tens)
    sig_eff_corr6 = sig_eff_tr6 - C0 @ dep_voigt
    sig_eff_corr = stress_voigt_to_tens_t(sig_eff_corr6)
    sigma_new_phys = effective_to_physical_t(sig_eff_corr, D_new)

    # Update backstress algebraically without adding tensor unknowns.
    back_new_phys = (back_old_phys + a_unit * dp * N_phys) / (1.0 + s_unit * dp + 1e-30)
    back_new_eff = physical_to_effective_t(back_new_phys, D_new)

    s_eff_new, hyd_eff_new = split_t(sig_eff_corr)
    zeta_new = s_eff_new - back_new_eff
    seq_eff_new = torch.sqrt(1.5 * ddot(zeta_new, zeta_new) + 1e-30)

    damage_prefactor = (D_cr / (e_r - e_d + 1e-30))
    damage_prefactor = damage_prefactor * (
        (2.0 / 3.0) * (1.0 + nu)
        + (3.0 - 6.0 * nu) * (hyd_eff_new / (seq_eff_new + 1e-30)) ** 2
    )
    eps_pl_dot_diag = torch.abs(torch.diag(eps_pl_dot))
    D_target = torch.diag(D_old) + dt * damage_prefactor * eps_pl_dot_diag

    R_sigma33 = sigma_new_phys[2, 2]
    R_damage = torch.diag(D_new) - D_target
    residual = torch.cat([torch.stack([R_sigma33, R_vp]), R_damage])

    aux = {
        "delta_eps": delta_eps,
        "sig_eff_tr6": sig_eff_tr6,
        "sigma_tr_eff": sig_eff_tr,
        "sigma_new_phys": sigma_new_phys,
        "sigma_new_eff": sig_eff_corr,
        "back_new_phys": back_new_phys,
        "dep_tens": dep_tens,
        "N_phys": N_phys,
        "D_new": D_new,
        "J": J,
        "h": h,
    }
    return residual, aux


def local_residual_torch(xvec, delta_eps6, state_old_np, params_np):
    return local_response_torch(xvec, delta_eps6, state_old_np, params_np)[0]


def elastic_plane_stress_eps33(delta_eps6, state_old_np, params_np, tol=1e-12, max_iter=30):
    eps33 = -(delta_eps6[0] + delta_eps6[1])
    sigma_old = state_old_np["stress_n"]
    D_old = state_old_np["D"]
    C0 = params_np["C0"]
    for _ in range(max_iter):
        de = make_delta_eps(delta_eps6, eps33)
        sigma_eff_old = physical_to_effective(sigma_old, D_old)
        sigma_eff_new = stress_voigt_to_tens(stress_tens_to_voigt(sigma_eff_old) + C0 @ de)
        sigma_phys_new = effective_to_physical(sigma_eff_new, D_old)
        r = sigma_phys_new[2, 2]
        if abs(r) < tol:
            return eps33
        h = 1e-8
        de_h = make_delta_eps(delta_eps6, eps33 + h)
        sigma_eff_h = stress_voigt_to_tens(stress_tens_to_voigt(sigma_eff_old) + C0 @ de_h)
        sigma_phys_h = effective_to_physical(sigma_eff_h, D_old)
        dr = (sigma_phys_h[2, 2] - r) / h
        eps33 -= r / (dr + 1e-30)
    return eps33


def trial_yield_function(delta_eps6, eps33, state_old_np, params_np):
    de = make_delta_eps(delta_eps6, eps33)
    sigma_old_eff = physical_to_effective(state_old_np["stress_n"], state_old_np["D"])
    back_old_eff = physical_to_effective(state_old_np["stress_back"], state_old_np["D"])
    sig_eff_tr = stress_voigt_to_tens(stress_tens_to_voigt(sigma_old_eff) + params_np["C0"] @ de)
    s_eff_tr, _ = split(sig_eff_tr)
    zeta = s_eff_tr - back_old_eff
    seq = np.sqrt(max(0.0, 1.5 * np.tensordot(zeta, zeta)))
    return seq - params_np["stress_yield"], seq


def solve_local_newton(delta_eps6, state_old_np, params_np, tol=1e-10, max_iter=40, verbose=False):
    eps33_guess = elastic_plane_stress_eps33(delta_eps6, state_old_np, params_np)
    phi_trial, seq_trial = trial_yield_function(delta_eps6, eps33_guess, state_old_np, params_np)

    if phi_trial <= 0.0:
        de = make_delta_eps(delta_eps6, eps33_guess)
        sigma_old_eff = physical_to_effective(state_old_np["stress_n"], state_old_np["D"])
        sigma_eff_new = stress_voigt_to_tens(stress_tens_to_voigt(sigma_old_eff) + params_np["C0"] @ de)
        sigma_phys_new = effective_to_physical(sigma_eff_new, state_old_np["D"])
        return {
            "status": "elastic",
            "iters": 0,
            "x": np.array([eps33_guess, 0.0, *np.diag(state_old_np["D"])]),
            "sigma_new_phys": sigma_phys_new,
            "sigma_new_eff": sigma_eff_new,
            "back_new_phys": state_old_np["stress_back"].copy(),
            "dep_tens": np.zeros((3, 3)),
            "N_phys": np.zeros((3, 3)),
            "D_new": state_old_np["D"].copy(),
            "delta_eps": de,
            "sig_eff_tr6": stress_tens_to_voigt(sigma_eff_new),
            "sigma_tr_eff": sigma_eff_new,
            "phi_trial": phi_trial,
            "seq_trial": seq_trial,
        }

    dp0 = max(1e-10, ((max(phi_trial, 1e-12) / params_np["stress_K"]) ** params_np["N"]) * params_np["timeincrement"])
    x = np.array([eps33_guess, dp0, *np.diag(state_old_np["D"])], dtype=float)
    delta_eps_t = torch.as_tensor(np.asarray(delta_eps6, dtype=float), dtype=DTYPE)
    last_norm = None

    for it in range(max_iter):
        x_t = torch.tensor(x, dtype=DTYPE, requires_grad=True)
        r_t = local_residual_torch(x_t, delta_eps_t, state_old_np, params_np)
        J_t = jacfwd(lambda y: local_residual_torch(y, delta_eps_t, state_old_np, params_np))(x_t)

        r = r_t.detach().cpu().numpy()
        J = J_t.detach().cpu().numpy()
        res_norm = np.linalg.norm(r)
        last_norm = res_norm
        if verbose:
            print(f"it={it:02d}  ||R||={res_norm:.6e}  x={x}")
        if res_norm < tol:
            break

        dx = np.linalg.solve(J + 1e-14 * np.eye(5), -r)
        step = 1.0
        accepted = False
        best_x = x.copy()
        best_norm = res_norm
        for _ in range(10):
            x_trial = x + step * dx
            x_trial[1] = max(x_trial[1], 1e-14)
            x_trial[2:] = np.clip(x_trial[2:], 0.0, 0.99)
            xt_t = torch.tensor(x_trial, dtype=DTYPE, requires_grad=False)
            rt = local_residual_torch(xt_t, delta_eps_t, state_old_np, params_np).detach().cpu().numpy()
            trial_norm = np.linalg.norm(rt)
            if trial_norm < best_norm:
                best_x = x_trial.copy()
                best_norm = trial_norm
            if trial_norm < res_norm:
                x = x_trial
                accepted = True
                break
            step *= 0.5
        if not accepted:
            x = best_x

    x_t = torch.tensor(x, dtype=DTYPE, requires_grad=False)
    _, aux = local_response_torch(x_t, delta_eps_t, state_old_np, params_np)
    return {
        "status": "plastic",
        "iters": it + 1,
        "x": x,
        "sigma_new_phys": aux["sigma_new_phys"].detach().cpu().numpy(),
        "sigma_new_eff": aux["sigma_new_eff"].detach().cpu().numpy(),
        "sigma_tr_eff": aux["sigma_tr_eff"].detach().cpu().numpy(),
        "sig_eff_tr6": aux["sig_eff_tr6"].detach().cpu().numpy(),
        "back_new_phys": aux["back_new_phys"].detach().cpu().numpy(),
        "dep_tens": aux["dep_tens"].detach().cpu().numpy(),
        "N_phys": aux["N_phys"].detach().cpu().numpy(),
        "D_new": aux["D_new"].detach().cpu().numpy(),
        "delta_eps": aux["delta_eps"].detach().cpu().numpy(),
        "res_norm": last_norm,
        "phi_trial": phi_trial,
        "seq_trial": seq_trial,
    }


def plane_stress_tangent_AD(x_np, delta_eps6_np, state_old_np, params_np):
    eps_in = torch.as_tensor(np.asarray(delta_eps6_np, dtype=float), dtype=DTYPE)
    x = torch.as_tensor(np.asarray(x_np, dtype=float), dtype=DTYPE).requires_grad_(True)

    def residual_given_x(xvec, epsbase):
        return local_residual_torch(xvec, epsbase, state_old_np, params_np)

    def stress_voigt_given_x(xvec, epsbase):
        _, aux = local_response_torch(xvec, epsbase, state_old_np, params_np)
        return stress_tens_to_voigt_t(aux["sigma_new_phys"])

    inplane_ids = [0, 1, 5]
    e6 = eps_in.clone().requires_grad_(True)

    A = jacfwd(lambda xx: residual_given_x(xx, e6))(x)
    B = jacfwd(lambda ee: residual_given_x(x, ee))(e6)
    Sx = jacfwd(lambda xx: stress_voigt_given_x(xx, e6))(x)
    Se = jacfwd(lambda ee: stress_voigt_given_x(x, ee))(e6)

    A_np = A.detach().cpu().numpy()
    B_np = B.detach().cpu().numpy()
    Sx_np = Sx.detach().cpu().numpy()
    Se_np = Se.detach().cpu().numpy()
    dx_de = -np.linalg.solve(A_np + 1e-14 * np.eye(5), B_np)
    full = Se_np + Sx_np @ dx_de
    Cep = full[np.ix_(inplane_ids, inplane_ids)]
    return Cep, full


def update_material_point(mat_params, delta_eps6, verbose=False):
    # Core FE entry point: update one material point for one strain increment.
    # In an FE code, this is the function that should be called inside the
    # element/integration-point loop.
    state_old = {
        "stress_n": mat_params["stress_n"].copy(),
        "stress_back": mat_params["stress_back"].copy(),
        "D": mat_params["D"].copy(),
        "eps_pl_tens": mat_params["eps_pl_tens"].copy(),
        "eps_el_tens": mat_params["eps_el_tens"].copy(),
        "EQPLAS": float(mat_params["EQPLAS"]),
    }

    params = {
        k: v for k, v in mat_params.items() if k in {
            "timeincrement", "N", "stress_yield", "stress_K", "mu", "pois",
            "a_unit", "s_unit", "a", "s", "D_cr", "e_d", "e_r", "C0",
        }
    }

    result = solve_local_newton(delta_eps6, state_old, params, verbose=verbose)
    x = result["x"]
    eps33 = x[0]
    dp = max(float(x[1]), 0.0)

    mat_params["delta_eps"] = result["delta_eps"].copy()
    mat_params["stress_n"] = result["sigma_new_phys"].copy()
    mat_params["stress_back"] = result["back_new_phys"].copy()
    mat_params["D"] = result["D_new"].copy()
    mat_params["eps_pl_tens"] = state_old["eps_pl_tens"] + result["dep_tens"]
    mat_params["eps_el_tens"] = state_old["eps_el_tens"] + strain_voigt_to_tens(result["delta_eps"]) - result["dep_tens"]
    mat_params["EQPLAS"] = state_old["EQPLAS"] + dp
    mat_params["Delta_pl"] = dp

    if result["status"] == "plastic":
        Cep_ps, Cep_full = plane_stress_tangent_AD(x, delta_eps6, state_old, params)
        mat_params["C_ep_ps"] = Cep_ps
        mat_params["C_ep"] = Cep_full
    else:
        mat_params["C_ep_ps"] = mat_params["C0"][np.ix_([0, 1, 5], [0, 1, 5])].copy()
        mat_params["C_ep"] = mat_params["C0"].copy()

    total_strain = strain_tens_to_voigt(mat_params["eps_el_tens"] + mat_params["eps_pl_tens"])
    total_stress = stress_tens_to_voigt(mat_params["stress_n"])
    mat_params["history_strain"].append(total_strain.copy())
    mat_params["history_stress"].append(total_stress.copy())
    mat_params["history_damage"].append(np.diag(mat_params["D"]).copy())
    mat_params["history_eqplas"].append(mat_params["EQPLAS"])
    mat_params["history_eps33"].append(eps33)

    return mat_params, result


def load_strain_sequence(data, assume="increment"):
    arr = np.asarray(data, dtype=float)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    if arr.shape[1] != 6:
        raise ValueError(f"Expected a (T, 6) or (6,) strain array, got {arr.shape}")
    if assume.lower().startswith("total"):
        delta = np.zeros_like(arr)
        delta[0] = arr[0]
        delta[1:] = arr[1:] - arr[:-1]
        return delta
    return arr


def run_plane_stress_sequence(sequence, scale=1.0, assume="increment", verbose=False):
    # Standalone plane-stress sequence driver.
    mat_params = initialize_material_state()
    delta_seq = load_strain_sequence(sequence, assume=assume) * scale
    results = []
    for k, delta_eps6 in enumerate(delta_seq):
        mat_params, local_result = update_material_point(mat_params, delta_eps6, verbose=verbose)
        local_result["step"] = k
        results.append(local_result)
    return mat_params, results


def repeat_increment_from_csv(csv_path, steps=100, scale=20.0):
    # Standalone repeated-increment helper.
    delta = np.genfromtxt(csv_path, delimiter=",")
    delta = np.asarray(delta, dtype=float).reshape(6)
    seq = np.repeat(delta.reshape(1, 6), steps, axis=0)
    return run_plane_stress_sequence(seq, scale=scale, assume="increment")


def load_strain_sequence_npz(npz_path, key=None):
    data = np.load(npz_path)
    if key is None:
        if len(data.files) == 0:
            raise ValueError("NPZ has no arrays inside.")
        key = data.files[0]

    arr = np.asarray(data[key])
    if arr.ndim == 2 and arr.shape[0] == 6 and arr.shape[1] != 6:
        arr = arr.T
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    if arr.shape[1] != 6:
        raise ValueError(f"Expected strain array with 6 columns (Voigt). Got shape {arr.shape} from key='{key}'")
    return arr


def totals_to_increments(eps_total_6):
    eps_total_6 = np.asarray(eps_total_6)
    delta = np.zeros_like(eps_total_6)
    delta[0] = eps_total_6[0]
    delta[1:] = eps_total_6[1:] - eps_total_6[:-1]
    return delta


def _initializing_material_properties_implicit_ad_v1(
    pois=0.3, timeincrement=1e-6, N=8.15, m=0, n=0, ni=1, nl=1, nj=1, nk=1,
):
    mat_params = initialize_material_state(pois=pois, timeincrement=timeincrement, N=N)
    return mat_params, None, pois, timeincrement, N, m, n


def _material_behaviour_up_vp_gnl_new_implicit_ad_v1(mat_params, NEWTON, i, gauss_points, section_points):
    l = m = n = 0
    idx = f"{i+1}{l+1}{m+1}{n+1}"
    delta_eps6 = np.asarray(mat_params["delta_eps" + idx], dtype=float).reshape(6)

    mat_params, _ = update_material_point(mat_params, delta_eps6, verbose=False)
    mat_params["stress_n" + idx] = stress_tens_to_voigt(mat_params["stress_n"])
    mat_params["EQPLAS" + idx] = mat_params["EQPLAS"]
    mat_params["Delta_pl" + idx] = mat_params.get("Delta_pl", 0.0)
    return mat_params


def run_viscoplastic_model_npz(npz_path, *, strain_key=None, scale=1.0, assume="increment", sign=[1]):
    # Optional standalone driver used for replaying stored strain histories.
    # This is convenient for regression testing, but FE code will usually not
    # call this directly.
    mat_params, _, _, _, _, _, _ = _initializing_material_properties_implicit_ad_v1(
        pois=0.3, timeincrement=1e-6, N=8.15, m=0, n=0, ni=1, nl=1, nj=1, nk=1,
    )

    gauss_points = [0.0]
    section_points = [0.0]
    i = l = m = n = 0
    idx = f"{i+1}{l+1}{m+1}{n+1}"

    seq = load_strain_sequence_npz(npz_path, key=strain_key) * scale
    delta_seq = totals_to_increments(seq) if assume.lower().startswith("total") else seq

    sig11_hist, eqplas_hist, dp_hist = [], [], []

    for load_sign in sign:
        for t in range(delta_seq.shape[0]):
            mat_params["delta_eps" + idx] = delta_seq[t] * load_sign
            mat_params = _material_behaviour_up_vp_gnl_new_implicit_ad_v1(
                mat_params,
                NEWTON=1,
                i=i,
                gauss_points=gauss_points,
                section_points=section_points,
            )

            sig = mat_params["stress_n" + idx]
            sig11_hist.append(sig[0])
            eqplas_hist.append(mat_params["EQPLAS" + idx])
            dp_hist.append(mat_params.get("Delta_pl" + idx, 0.0))

    mat_params["C_ep" + idx] = np.asarray(mat_params.get("C_ep", np.zeros((6, 6))), dtype=float).copy()
    mat_params["final_stress"] = mat_params["stress_n" + idx].copy()
    mat_params["final_EQPLAS"] = float(mat_params["EQPLAS" + idx])
    mat_params["final_C_ep"] = mat_params["C_ep" + idx].copy()

    return mat_params, np.array(sig11_hist), np.array(eqplas_hist), np.array(dp_hist)


def build_legacy_compatible_results(mat_params, sig11_hist, eqplas_hist, dp_hist, input_sequence=None):
    # Compatibility adapter for code that expects the old implicit_visco_tejas
    # output names such as stress_n1111, EQPLAS1111, Delta_pl1111, and C_ep1111.
    idx = "1111"
    return {
        "strain": np.asarray(mat_params["history_strain"]),
        "stress": np.asarray(mat_params["history_stress"]),
        "damage": np.asarray(mat_params["history_damage"]),
        "eqplas": np.asarray(mat_params["history_eqplas"]),
        "eps33": np.asarray(mat_params["history_eps33"]),
        "sig11_hist": np.asarray(sig11_hist),
        "eqplas_hist": np.asarray(eqplas_hist),
        "dp_hist": np.asarray(dp_hist),
        "input_sequence": None if input_sequence is None else np.asarray(input_sequence),
        "final_stress": np.asarray(mat_params["final_stress"]),
        "final_EQPLAS": np.asarray(mat_params["final_EQPLAS"]),
        "final_C_ep": np.asarray(mat_params["final_C_ep"]),
        "stress_n" + idx: np.asarray(mat_params["stress_n" + idx]),
        "EQPLAS" + idx: np.asarray(mat_params["EQPLAS" + idx]),
        "Delta_pl" + idx: np.asarray(mat_params.get("Delta_pl" + idx, 0.0)),
        "C_ep" + idx: np.asarray(mat_params["C_ep" + idx]),
    }


def save_legacy_compatible_results_npz(out_path, mat_params, sig11_hist, eqplas_hist, dp_hist, *, input_sequence=None):
    results = build_legacy_compatible_results(
        mat_params,
        sig11_hist,
        eqplas_hist,
        dp_hist,
        input_sequence=input_sequence,
    )
    np.savez(out_path, **{k: v for k, v in results.items() if v is not None})
    return results


def run_and_save_default_strain_sequence(
    npz_path="/home/tejas24/viscoPlasticDamage/strain_sequence.npz",
    strain_key="x",
    out_path="/home/tejas24/viscoPlasticDamage/implicit_scheme/implicit_anisotropic_damage/implicit_anisotropic_damage_v5_strain_sequence_results.npz",
    *,
    scale=1.0,
    assume="total",
    sign=[1],
):
    # Optional executable entry point for the repository's default regression
    # strain sequence. Keep separate from FE use.
    input_sequence = load_strain_sequence_npz(npz_path, key=strain_key)
    mat_params, sig11_hist, eqplas_hist, dp_hist = run_viscoplastic_model_npz(
        npz_path,
        strain_key=strain_key,
        scale=scale,
        assume=assume,
        sign=sign,
    )
    results = save_legacy_compatible_results_npz(
        out_path,
        mat_params,
        sig11_hist,
        eqplas_hist,
        dp_hist,
        input_sequence=input_sequence,
    )
    return mat_params, results


def plot_history(mat_params, out_path="implicit_anisotropic_damage_plane_stress.png"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    strain = np.asarray(mat_params["history_strain"])
    stress = np.asarray(mat_params["history_stress"])
    damage = np.asarray(mat_params["history_damage"])

    fig, axes = plt.subplots(2, 2, figsize=(12, 9), constrained_layout=True)
    axes[0, 0].plot(strain[:, 0], stress[:, 0], label=r"$\sigma_{11}$")
    axes[0, 0].plot(strain[:, 1], stress[:, 1], label=r"$\sigma_{22}$")
    axes[0, 0].plot(strain[:, 5], stress[:, 5], label=r"$\sigma_{12}$")
    axes[0, 0].set_xlabel("Strain")
    axes[0, 0].set_ylabel("Stress")
    axes[0, 0].legend()
    axes[0, 0].grid(True, alpha=0.3)

    axes[0, 1].plot(damage[:, 0], label="D1")
    axes[0, 1].plot(damage[:, 1], label="D2")
    axes[0, 1].plot(damage[:, 2], label="D3")
    axes[0, 1].set_xlabel("Step")
    axes[0, 1].set_ylabel("Damage")
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3)

    axes[1, 0].plot(mat_params["history_eqplas"])
    axes[1, 0].set_xlabel("Step")
    axes[1, 0].set_ylabel("EQPLAS")
    axes[1, 0].grid(True, alpha=0.3)

    axes[1, 1].plot(mat_params["history_eps33"])
    axes[1, 1].set_xlabel("Step")
    axes[1, 1].set_ylabel(r"$\Delta \epsilon_{33}$")
    axes[1, 1].grid(True, alpha=0.3)

    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    return out_path


if __name__ == "__main__":
    _, results = run_and_save_default_strain_sequence()
    print("Stored strain-sequence run finished.")
    print("Number of increments:", len(results["sig11_hist"]))
    print("Maximum EQPLAS:", np.max(results["eqplas_hist"]) if len(results["eqplas_hist"]) else 0.0)
    print("Final damage diag:", results["damage"][-1] if len(results["damage"]) else np.zeros(3))
