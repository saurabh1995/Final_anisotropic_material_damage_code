#!/usr/bin/env python3
"""Run the packaged batched update on CUDA when available, otherwise CPU."""

from __future__ import annotations

import json
from pathlib import Path

import torch

import batched_anisotropic_damage_gpu as model


HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "gpu_demo_summary.json"


def main() -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    state = model.initialize_batch_state(4, device)
    delta = torch.tensor([[1e-5, -2e-6, 0.0, 0.0, 0.0, 3e-6]] * 4, dtype=model.DTYPE, device=device)
    state, result = model.update_material_points_gpu(state, delta)
    output = {
        "device": str(device),
        "points": 4,
        "status_codes": result["status_code"].detach().cpu().tolist(),
        "max_abs_sigma33": float(torch.max(torch.abs(state["stress_n"][:, 2, 2])).cpu()),
        "C_ep_ps_first_point": state["C_ep_ps"][0].detach().cpu().tolist(),
    }
    OUTPUT.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
