# Explicit Anisotropic Damage Model

`explicit_anisotropic_damage.py` implements an explicit Euler update for
anisotropic viscoplastic damage under plane-stress conditions.

Run the included example from the package root:

```bash
python explicit_anisotropic/run_explicit_anisotropic.py --steps 8
```
