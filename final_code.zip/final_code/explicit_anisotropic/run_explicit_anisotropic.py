#!/usr/bin/env python3
"""Run the explicit anisotropic-damage material-point simulation."""

from __future__ import annotations

import argparse
import importlib.util
import os
import sys
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mplconfig")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PLANE_STRESS_COMPONENTS = [0, 1, 5]
VOIGT_LABELS = [(r"$\sigma_{11}$", r"$\epsilon_{11}$"), (r"$\sigma_{22}$", r"$\epsilon_{22}$"),
                (r"$\sigma_{33}$", r"$\epsilon_{33}$"), (r"$\sigma_{23}$", r"$\gamma_{23}$"),
                (r"$\sigma_{13}$", r"$\gamma_{13}$"), (r"$\sigma_{12}$", r"$\gamma_{12}$")]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def save_history(prefix: str, state: dict) -> tuple[np.ndarray, np.ndarray]:
    strain = np.asarray(state["abs_strain1111"], dtype=float)
    stress = np.asarray(state["abs_stress1111"], dtype=float)
    np.savetxt(HERE / f"{prefix}_strain.csv", strain, delimiter=",")
    np.savetxt(HERE / f"{prefix}_stress.csv", stress, delimiter=",")
    return strain, stress


def damage_diagonal(state: dict) -> np.ndarray:
    return np.diag(np.asarray(state["D1111"], dtype=float))


def plastic_strain_diagonal(state: dict) -> np.ndarray:
    return np.diag(np.asarray(state["eps_pl_tens1111"], dtype=float))


def plot_on_off(damage_off: tuple[np.ndarray, np.ndarray],
                damage_on: tuple[np.ndarray, np.ndarray]) -> None:
    off_e, off_s = damage_off
    on_e, on_s = damage_on
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5), constrained_layout=True)
    for component, ax in zip(PLANE_STRESS_COMPONENTS, axes.ravel()):
        ax.plot(off_e[:, component], off_s[:, component], label="Corrected anisotropic damage off", lw=1.7)
        ax.plot(on_e[:, component], on_s[:, component], "--", label="Corrected anisotropic damage on", lw=1.7)
        ax.set_title(VOIGT_LABELS[component][0])
        ax.set_xlabel(VOIGT_LABELS[component][1])
        ax.set_ylabel("Stress")
        ax.grid(alpha=0.3)
        ax.legend(fontsize=8)
    fig.suptitle("Paper-corrected anisotropic damage: on vs off", fontsize=14)
    fig.savefig(HERE / "Paper-corrected anisotropic damage on vs off.png", dpi=200)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=HERE.parent / "inputs" / "strain43111.csv", help="6-component strain-increment CSV")
    parser.add_argument("--steps", type=int, default=100_000, help="increments per loading segment")
    parser.add_argument("--scale", type=float, default=2500.0, help="multiplier applied to the input strain increment")
    parser.add_argument("--sign", type=int, nargs="+", default=[1], help="loading sign(s), e.g. 1 -1")
    parser.add_argument("--history-stride", type=int, default=50, help="retain one plot point per this many increments")
    args = parser.parse_args()
    if args.steps < 1 or args.history_stride < 1:
        parser.error("--steps and --history-stride must be positive")

    model = load_module("explicit_anisotropic_damage", HERE / "explicit_anisotropic_damage.py")
    input_path = args.input.resolve()
    old_cwd = Path.cwd()
    os.chdir(HERE)
    try:
        off_state = model.run_explicit_anisotropic_simulation(input_path, steps=args.steps, scale=args.scale,
                                                  sign=args.sign, plot=False, show=False,
                                                  damage_enabled=False, history_stride=args.history_stride)
        on_state = model.run_explicit_anisotropic_simulation(input_path, steps=args.steps, scale=args.scale,
                                                 sign=args.sign, plot=False, show=False,
                                                 damage_enabled=True, history_stride=args.history_stride)
    finally:
        os.chdir(old_cwd)

    damage_off = save_history("corrected_anisotropic_damage_off", off_state)
    damage_on = save_history("corrected_anisotropic_damage_on", on_state)
    plot_on_off(damage_off, damage_on)

    d_on = damage_diagonal(on_state)
    epsp_on = plastic_strain_diagonal(on_state)
    np.savetxt(HERE / "corrected_anisotropic_damage_on_final_damage_diagonal.csv", d_on[None, :], delimiter=",")
    np.savetxt(HERE / "corrected_anisotropic_damage_on_final_plastic_strain_diagonal.csv", epsp_on[None, :], delimiter=",")

    stress_difference = np.abs(damage_off[1][:, PLANE_STRESS_COMPONENTS] - damage_on[1][:, PLANE_STRESS_COMPONENTS])
    max_difference = float(np.max(stress_difference))
    max_reference_stress = float(np.max(np.abs(damage_off[1][:, PLANE_STRESS_COMPONENTS])))
    (HERE / "comparison_summary.txt").write_text(
        f"input: {input_path}\nsteps_per_segment: {args.steps}\nsegments: {len(args.sign)}\nscale: {args.scale}\n"
        f"history_stride: {args.history_stride}\n"
        f"corrections: plastic strain tensor accumulated; D_dot_i from abs plastic normal strain rate; D3 forced to zero; eps33 iterated from actual sigma33 residual; eps_p33_dot forced to zero\n"
        f"integration: explicit Euler, trapezoidal rule intentionally ignored\n"
        f"damage_off_final_eqplas: {float(off_state['EQPLAS1111']):.12g}\n"
        f"damage_on_final_eqplas: {float(on_state['EQPLAS1111']):.12g}\n"
        f"damage_on_final_damage_diagonal: {d_on.tolist()}\n"
        f"damage_on_final_plastic_strain_diagonal: {epsp_on.tolist()}\n"
        f"components_compared: sigma11, sigma22, sigma12\n"
        f"maximum_in_plane_stress_difference: {max_difference:.12g}\n"
        f"maximum_in_plane_relative_difference: {max_difference / max_reference_stress:.6%}\n"
        f"damage_off_final_sigma33: {float(damage_off[1][-1, 2]):.12g}\n"
        f"damage_on_final_sigma33: {float(damage_on[1][-1, 2]):.12g}\n"
    )
    print(f"Saved explicit anisotropic simulation results to {HERE}")


if __name__ == "__main__":
    main()
