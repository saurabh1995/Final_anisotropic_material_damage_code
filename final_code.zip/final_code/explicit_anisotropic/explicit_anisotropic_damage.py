import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from datetime import datetime
start_time = datetime.now()




def props_update(mat_params, i,l,j,k, pois):
    
    return (mat_params['E'+str(i+1)+str(l+1)+str(j+1)+str(k+1)]*pois)/((1 + pois)*(1 - 2*pois)), 0.5*mat_params['E'+str(i+1)+str(l+1)+str(j+1)+str(k+1)]/(1 + pois)


def tens_to_voigt(tens):
    
    stress    = np.zeros(shape=(6,))
    
    stress[0] = tens[0][0]
    stress[1] = tens[1][1]
    stress[2] = tens[2][2]
    stress[3] = tens[1][2]
    stress[4] = tens[0][2]
    stress[5] = tens[0][1]
    
    return stress



def voigt_to_tens(voigt):

    stress = np.zeros(shape=(3,3))

    stress[0][0] = voigt[0]
    stress[1][1] = voigt[1]
    stress[2][2] = voigt[2]
    stress[1][2] = voigt[3]
    stress[2][1] = voigt[3]
    stress[0][2] = voigt[4]
    stress[2][0] = voigt[4]
    stress[0][1] = voigt[5]
    stress[1][0] = voigt[5]

    return stress


# spliting stress tensor into deviotoric and hydrostatic parts
def split(tens):
   
    I      = np.eye(3,3)
    if tens.shape == (6,):
        aa     = voigt_to_tens(tens)
        
    else:
        aa     = tens
        
    shydro = (1/3*(aa.trace()))
    #aa     = voigt_to_tens(tens)
      
    return aa - shydro*I, shydro



def initialize_material_state(
    pois: float = 0.3,
    timeincrement: float = 1e-6,
    N: float = 8.15,
    m: int = 0,
    n: int = 0,
    ni: int = 1, nl: int = 1, nj: int = 1, nk: int = 1,   # loop extents
    E_default: float = 113066.0,
    yield_default: float = 180.0,
) -> tuple[dict, np.ndarray, float, float, float, int, int]:
    """
    Initialize `mat_params` dict and related constants.

    Returns
    -------
    mat_params, I, pois, timeincrement, N, m, n
    """
    mat_params: dict = {}
    I = np.eye(3)

    for i in range(ni):
        for l in range(nl):
            for j in range(nj):
                for k in range(nk):
                    idx = f"{i+1}{l+1}{j+1}{k+1}"

                    mat_params[f'stress_eqv_trial{idx}'] = 0.0
                    mat_params[f'stress_tens{idx}']      = np.zeros((3,3))
                    mat_params[f'flow{idx}']              = np.zeros((3,3))
                    mat_params[f'eps_tens{idx}']          = np.zeros((3,3))
                    mat_params[f'eps_pl_tens{idx}']       = np.zeros((3,3))
                    mat_params[f'eps_el_tens{idx}']       = np.zeros((3,3))
                    mat_params[f'eps{idx}']               = np.zeros((3,3))
                    mat_params[f'stress_n{idx}']          = np.zeros((3,3))
                    mat_params[f'stress_yield{idx}']      = yield_default
                    mat_params[f'E{idx}']                 = E_default
                    mat_params[f'delta_eps{idx}']         = np.zeros((6,))
                    mat_params[f'delta_eps_cor{idx}']     = np.zeros((6,))

                    # Lame parameters from your helper
                    lam, mu = props_update(mat_params, i, l, j, k, pois)
                    mat_params[f'lam{idx}'] = lam
                    mat_params[f'mu{idx}']  = mu
                    mat_params[f'pois{idx}'] = pois

                    mat_params[f'stress_n-1{idx}']        = np.zeros((6,))
                    mat_params[f'stress_eff_n-1{idx}']   = np.zeros((6,))
                    mat_params[f'eps_vec{idx}']           = np.zeros((6,))

                    aa = 2.0*mu + lam  # convenience for stiffness assembly

                    mat_params[f'stress_K{idx}']          = 11.45
                    mat_params[f'abs_stress{idx}']        = []
                    mat_params[f'stress_back{idx}']       = np.zeros((3,3))
                    mat_params[f'stress_back_n-1{idx}']   = np.zeros((3,3))
                    mat_params[f'stress_back_eff_n-1{idx}']= np.zeros((3,3))
                    mat_params[f'abs_strain{idx}']        = []

                    # Elastic tangent C (Voigt 6x6)
                    mat_params[f'C{idx}'] = np.array([
                        [aa,  lam, lam, 0,   0,   0],
                        [lam, aa,  lam, 0,   0,   0],
                        [lam, lam, aa,  0,   0,   0],
                        [0,   0,   0,   mu,  0,   0],
                        [0,   0,   0,   0,   mu,  0],
                        [0,   0,   0,   0,   0,   mu],
                    ], dtype=float)

                    mat_params[f'C0{idx}']        = mat_params[f'C{idx}'].copy()

                    mat_params[f'C_evp_fourth{idx}'] = np.zeros((3,3,3,3))
                    mat_params[f'C_evp{idx}']        = mat_params[f'C{idx}'].copy()
                    mat_params[f'abs_eqpl{idx}']     = []

                    mat_params[f'C_ep{idx}'] = np.array([
                        [aa,  lam, lam, 0,   0,   0],
                        [lam, aa,  lam, 0,   0,   0],
                        [lam, lam, aa,  0,   0,   0],
                        [0,   0,   0,   mu,  0,   0],
                        [0,   0,   0,   0,   mu,  0],
                        [0,   0,   0,   0,   0,   mu],
                    ], dtype=float)

                    mat_params[f'eps_dot{idx}'] = 0.0
                    mat_params[f'X_dot{idx}']   = np.zeros((3,3))
                    mat_params[f'D_dot{idx}']   = np.zeros(3)

                    # Equivalent plastic strain (current state)
                    mat_params[f'EQPLAS{idx}'] = np.sqrt(
                        np.tensordot(mat_params[f'eps_pl_tens{idx}'],
                                     mat_params[f'eps_pl_tens{idx}'], axes=2) * (2.0/3.0)
                    )

                    mat_params[f'eps_pl_dot{idx}'] = np.zeros((3,3))

                    # Bulk modulus if you need it later (not stored before)
                    K = E_default / (1.0 - 2.0*pois)  # noqa: F841 (kept for parity)

                    mat_params[f'Delta_d{idx}'] = 0.0
                    mat_params[f'R{idx}']       = 0.0
                    mat_params[f'b1{idx}']      = 0.0
                    mat_params[f'b2{idx}']      = 0.0
                    mat_params[f'D{idx}']       = np.zeros((3,3))
                    mat_params[f'D_cr{idx}']    = 0.22
                    mat_params[f'e_d{idx}']     = 0.0
                    mat_params[f'e_r{idx}']     = 0.16296296296296295
                    mat_params[f'a{idx}']       = 98939.30
                    mat_params[f's{idx}']       = 1533.41

    # stash globals you used so downstream code can access them if needed
    mat_params['timeincrement'] = timeincrement
    mat_params['N'] = N
    mat_params['m'] = m
    mat_params['n'] = n

    return mat_params, I, pois, timeincrement, N, m, n


'''def damage_multiplier_matrix(D):
    H  = np.array([[1/np.sqrt(1-D[0][0]), 0,0],
                   [0,1/np.sqrt(1-D[1][1]),0],
                   [0,0,1/np.sqrt(1-D[2][2])]])
    return H


def stress_with_damage(stress):

    stress_deviotoric, stress_hydriostatic = split(stress)

    stress_d = damage_multiplier_matrix(mat_params['D1111'])@stress_deviotoric@damage_multiplier_matrix(mat_params['D1111'])
    return stress_d'''


#damage_scalar_mean calculates hydrostatic damage D_H
def damage_scalar_mean(D, eps: float = 1e-12):
    D = np.asarray(D, dtype=float)
    d = np.diag(D) if D.shape == (3,3) else D.reshape(3)
    return float(np.clip(np.mean(d), 0.0, 1.0 - eps))


#damage_multiplier_inverse calculates the H-1 tensor (referring from the Prof. Stoffel paper)
def damage_multiplier_inverse(D, eps: float = 1e-12):
    # H^{-1} = diag(sqrt(1 - D_i))
    D = np.asarray(D, dtype=float)
    if D.shape == (3, 3):
        d = np.array([D[0,0], D[1,1], D[2,2]], dtype=float)
    else:
        d = D.reshape(3).astype(float)
    d = np.clip(d, 0.0, 1.0 - eps)
    return np.diag(np.sqrt(1.0 - d))

def damage_multiplier(D, eps: float = 1e-12):
    # H = diag(1 / sqrt(1 - D_i))
    D = np.asarray(D, dtype=float)
    if D.shape == (3, 3):
        d = np.array([D[0,0], D[1,1], D[2,2]], dtype=float)
    else:
        d = D.reshape(3).astype(float)
    d = np.clip(d, 0.0, 1.0 - eps)
    return np.diag(1.0 / np.sqrt(1.0 - d))


def effective_to_physical(sigma,D,index):
    dev, hyd = split(sigma) 
    #H    = damage_multiplier_matrix(D)
    Hinv = damage_multiplier_inverse(D)
    D_H  = damage_scalar_mean(D)
    sigma_dev = Hinv @ dev @ Hinv
    sigma_tilde = sigma_dev + (1.0 - D_H)*hyd*np.eye(3)
    if index==1:
        return sigma_tilde
    elif index==2:
        return sigma_dev
    

def physical_to_effective(sigma, D, index):
    dev, hyd = split(sigma) 
    #H    = damage_multiplier_matrix(D)
    H = damage_multiplier(D)
    D_H  = damage_scalar_mean(D)
    sigma_dev = H @ dev @ H
    sigma_bar = sigma_dev + (1.0/(1.0 - D_H))*hyd*np.eye(3)
    if index==1:
        return sigma_bar
    elif index==2:
        return sigma_dev


def paper_anisotropic_damage_rate(mat_params, idx: str, stress_hydro: float,
                                  stress_eqv: float, eps_pl_dot: np.ndarray) -> np.ndarray:
    """Lemaitre/Stoffel anisotropic damage rate for the shell adaptation.

    The paper evolves each damage direction with the absolute plastic normal
    strain rate in that direction.  For the shell theory used there, thickness
    plastic strain is neglected, so D3_dot is set to zero.
    """
    if stress_eqv <= 1e-14:
        multiaxial_factor = (2.0 / 3.0) * (1.0 + mat_params[f'pois{idx}'])
    else:
        multiaxial_factor = (
            (2.0 / 3.0) * (1.0 + mat_params[f'pois{idx}'])
            + 3.0 * (1.0 - 2.0 * mat_params[f'pois{idx}']) * (stress_hydro / stress_eqv) ** 2
        )
    damage_slope = mat_params[f'D_cr{idx}'] / (mat_params[f'e_r{idx}'] - mat_params[f'e_d{idx}'])
    normal_plastic_rate = np.abs(np.diag(eps_pl_dot)).astype(float)
    normal_plastic_rate[2] = 0.0
    return damage_slope * multiaxial_factor * normal_plastic_rate


def integrate_explicit_viscoplastic_step(mat_params, i, N, timeincrement, number_of_iteration, wahl, stress_eqv_trial,stress_back_trial, stress_dev_trial,l,m,n, N_dirr):
       
    
    Delta_pl_U     =  mat_params['eps_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*timeincrement 
    return Delta_pl_U, mat_params






def run_explicit_anisotropic_simulation(csv_path: str,
    *,
    scale: float = 20.0,          # your old *10*2
    steps: int = 500_000,         # max time increments
    sign: int | list[int] = 1,    # one sign or a list of signs
    tol: float = 1e-4,
    max_iter: int = 1200,
    plot: bool = True,
    save_path: str | None = None,
    show: bool = False,
    damage_enabled: bool = True,
    damage_coupled: bool = True,
    history_stride: int = 1,
    initial_state: dict | None = None,):
    import argparse
    if history_stride < 1:
        raise ValueError("history_stride must be positive")
    from pathlib import Path
    if initial_state is None:
        mat_params, I, pois, timeincrement, N, m0, n0 = initialize_material_state(
            pois=0.3, timeincrement=1e-6, N=8.15, m=0, n=0, ni=1, nl=1, nj=1, nk=1
        )
    else:
        mat_params = initial_state
        I = np.eye(3)
        pois = mat_params['pois1111']
        timeincrement = mat_params['timeincrement']
        N = mat_params['N']
    i = 0         # single material point / index
    #l = 0; m = 0; n = 0  have been initialized below
    # earlier scale was unused here
    delta_st  = np.genfromtxt(csv_path, delimiter=',')*scale
    #delta_st  = np.genfromtxt(r'D:\Ameya\IAM-HIWI\Material_model\Saurabh_files\strain43111.csv', delimiter=',')*10*2
    #parser = argparse.ArgumentParser()
    #parser.add_argument("--csv", required=True, help="Path to input CSV")
    #args = parser.parse_args()

    #csv_path = args.csv
    #delta_st = np.genfromtxt(csv_path, delimiter=',')*10*2



    l = 0
    m = 0
    n = 0
    random   = 0
    Delta_pl = 0
    wahl    = 0
    deqpl   = []
    deqpl1           = []
    deqpl2           = []
    eps33_ana        = []
    eps33_ana_pl     = []
    count_tr         = 0
    sequence_tracker = 0
    trial_stress = []
    back_stress  = []
    training_data = []
    number_of_iteration = 0
    iterations          = []
    start_time = datetime.now()

    sign = [sign] if np.isscalar(sign) else list(sign)
    increment_s = [steps] * len(sign)

    for ll in range(len(sign)):
        
        print('......................................................................................................')
        print('Load Sequence '+str(ll+1)+' The sign is '+str(sign[l]))
        print('......................................................................................................')
        
        for t in range(increment_s[ll]):

            #taking input from csv file for strain    
            mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]                    = delta_st*1*sign[ll]
            
            #print(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])

            for l in range((1)):

                for m in range((1)):

                    for n in range((1)):

                        idx = str(i+1)+str(l+1)+str(m+1)+str(n+1)
                        zero_damage = np.zeros((3, 3))
                        flow_damage = mat_params['D'+idx] if damage_coupled else zero_damage
                        mat_params['stress_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]      = tens_to_voigt(mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].copy())
                        #print(mat_params['stress_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].shape)
                        mat_params['stress_eff_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = physical_to_effective(mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)], flow_damage, 1).copy()
                        #sig_tr_i_1                                                        = mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]    + (1-mat_params['D'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])*mat_params['C'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].dot(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                        sig_tr_eff_i_1                                                    = tens_to_voigt(mat_params['stress_eff_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]) + mat_params['C0'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].dot(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                        mat_params['stress_back_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = mat_params['stress_back'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].copy()
                        mat_params['stress_back_eff_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = physical_to_effective(mat_params['stress_back'+str(i+1)+str(l+1)+str(m+1)+str(n+1)], flow_damage, 1).copy()
                        #mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]    = mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]    + mat_params['C'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].dot(mat_params['delta_eps_cor'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]) 
                        #mat_params['eps_el_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = mat_params['eps_el_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] + voigt_to_tens(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])  
                        stress_back_trial                                                 = mat_params['stress_back'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].copy()
                        stress_back_eff_trial                                             = physical_to_effective(mat_params['stress_back'+str(i+1)+str(l+1)+str(m+1)+str(n+1)], flow_damage, 1).copy()
                        #mat_params['stress_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = voigt_to_tens(mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                        #now the stress deviatoric part is calculated in effective space
                        stress_dev_trial,stress_sph                                        = split(sig_tr_eff_i_1)
                        #if i==0 and m==0 and n==0:
                        #    print(mat_params['stress_n111'])
                        #now we don't need this as we are directly getting the scalar value from split() function #sph_   = (1/3)*(stress_sph.trace())

                        #it is S-X in the Recurrent neural networks paper
                        ############zeta changed to effective space which automatically converts other variables (stress_eqv_trial, N_dirr) to the effective space as well########################
                        zeta                                                              = stress_dev_trial-stress_back_eff_trial  
                        stress_eqv_trial                                                  = np.sqrt(1.5*(np.tensordot(zeta, zeta)))    
                        N_dirr                                                            = ((zeta)/stress_eqv_trial)
                        N_dirr_eff_ph                                                        = effective_to_physical(N_dirr.copy(), flow_damage, 1)

                        # von mises equivalent stress of stress deviatioric part
                        J_s                                                               = np.sqrt(1.5*(np.tensordot(stress_dev_trial, stress_dev_trial)))    
                        
                        # Write a function to give the current yield stress
                        #mat_params['stress_yield'+str(i+1)+str(l+1)+str(m+1)+str(n+1)], mat_params['H'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = Uhard(mat_params['EQPLAS'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                        #print(mat_params)
                        # Checking Yield Condition using Peryzna model
                        phi = stress_eqv_trial - (mat_params['stress_yield'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] + mat_params['R'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                        
                        if phi > 0:
                            
                            #print('Wir befinden uns weiter im Nichtlinearen Bereich')
                            #print('Hello')

                            N_dirr_bef = (N_dirr_eff_ph.copy())*stress_eqv_trial
                            '''if count_tr==0 and mat_params['stress_back'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][0][0]==0:
                                sequence_tracker=0
                                #mat_params['D1111'] = 0.004
                                count_tr=1

                            elif count_tr==0 and mat_params['stress_back'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][0][0]!=0:
                                sequence_tracker=1
                                count_tr=1'''

                            #print(t+1)

                            for p in range(max_iter):
                                
                                

                                if not(p==0):

                                    #mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]    = mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]    + mat_params['C'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].dot(mat_params['delta_eps_cor'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                                    #mat_params['eps_el_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = mat_params['eps_el_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] + voigt_to_tens(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])  
                                    #mat_params['stress_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = voigt_to_tens(mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                                    #stress_dev_trial                                              = mat_params['stress_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]-I*(1/3*mat_params['stress_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].trace())
                                    #if i==0 and m==0 and n==0:

                                    #print('hello')
                                    #    print(mat_params['stress_n111'])
                                    sig_tr_eff_i_1                                                  = tens_to_voigt(mat_params['stress_eff_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])    + mat_params['C0'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].dot(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                                    stress_dev_trial, stress_sph                                    = split(sig_tr_eff_i_1)
                                    zeta                                                            = stress_dev_trial - stress_back_eff_trial
                                    #stress_eqv_trial                                               = np.sqrt(1.5*(np.tensordot(zeta, zeta)))
                                    stress_eqv_trial                                                = np.sqrt(1.5*(np.tensordot(zeta, zeta)))    
                                    N_dirr                                                          = (zeta)/stress_eqv_trial
                                    N_dirr_eff_ph                                                   = effective_to_physical(N_dirr.copy(), flow_damage, 1)

                                    #sph_                                                          = (1/3)*(stress_sph.trace())
                                    sigma_trial_phys = effective_to_physical(sig_tr_eff_i_1.copy(), flow_damage, 1)
                                    sigma_33_trial                                                = sigma_trial_phys[2][2]
                                    #Delta_pl, mat_params, q, sigma_star_N                         = implicit_integration_vp_1(mat_params, i, N, timeincrement, 1, wahl, stress_eqv_trial,stress_back_trial, stress_dev_trial,l,m,n,N_dirr)
                                    #Delta_pl, mat_params, q, sigma_star_N                         = implicit_integration_vp(mat_params, i, N, timeincrement, number_of_iteration, wahl, stress_eqv_trial,stress_back_trial, stress_dev_trial,l,m,n, N_dirr)
                                    phi = stress_eqv_trial - (mat_params['stress_yield'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] + mat_params['R'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                                    positive_phi = max(float(phi), 0.0)
                                    mat_params['eps_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = (positive_phi/mat_params['stress_K'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])**N
                                    mat_params['eps_pl_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = 1.5*mat_params['eps_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*(N_dirr_eff_ph)
                                    mat_params['eps_pl_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][2][2] = 0.0
                                    Delta_pl_sigma33                                              = mat_params['eps_pl_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*timeincrement

                                    Delta_pl, mat_params                                          = integrate_explicit_viscoplastic_step(mat_params, i, N, timeincrement, number_of_iteration, wahl, stress_eqv_trial,stress_back_trial, stress_dev_trial,l,m,n, N_dirr_eff_ph)
                                    
                                    #D_sigma33                                                     = mat_params['D'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] + (mat_params['D_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*timeincrement)


                                    sigma_eff_corr_iteration = sig_tr_eff_i_1 - mat_params['C0'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]@(tens_to_voigt(mat_params['eps_pl_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])*timeincrement)
                                    sigma_i_1 = effective_to_physical(
                                        sigma_eff_corr_iteration,
                                        flow_damage,
                                        1
                                    )[2][2]
                                    
                                    delta_eps33_i_1                                               = delta_eps33_i_minus_1 -(((sigma_i)*(delta_eps33_i - delta_eps33_i_minus_1))/(1e-9 + sigma_i_1 - sigma_i))


                                    
                                    mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][2] = delta_eps33_i_1
                                    delta_eps33_i_minus_1 =  delta_eps33_i
                                    delta_eps33_i         =  delta_eps33_i_1
                                    sigma_i               =  sigma_i_1
        #                             a1r, b1r, c1r, d1r, e1r, f1r     =   ML.tens_to_voigt(stress_dev_trial)
        #                             a2r, b2r, c2r, d2r, e2r, f2r     =   ML.tens_to_voigt(stress_back_trial)
        #                             trial_stress.append([a1r, b1r, c1r, d1r, e1r, f1r])
        #                             back_stress.append([a2r, b2r, c2r, d2r, e2r, f2r])
        #                             if sequence_tracker==0:
        #                                 deqpl1.append(Delta_pl)

        #                             elif sequence_tracker==1:

        #                                 deqpl2.append(Delta_pl)
                                    #print(abs(delta_eps33_i - delta_eps33_i_minus_1)/abs(delta_eps33_i_1))

                                    if abs(sigma_i_1) < 1e-8 or abs(delta_eps33_i - delta_eps33_i_minus_1)/max(abs(delta_eps33_i_1), 1e-30) < 1e-4:

                                        #print('Wir befinden uns weiter im Nichtlinearen Bereich und Konvergieren in '+str(p+1)+' Iterations', 'zeitinkrement'+str(t+1))   
                                        deqpl1.append(Delta_pl)
                                        a1r, b1r, c1r, d1r, e1r, f1r     =   tens_to_voigt(stress_dev_trial)
                                        a2r, b2r, c2r, d2r, e2r, f2r     =   tens_to_voigt(stress_back_trial)
                                        trial_stress.append([a1r, b1r, c1r, d1r, e1r, f1r])
                                        back_stress.append([a2r, b2r, c2r, d2r, e2r, f2r])
                                        mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][2] = delta_eps33_i_1
                                        #eps33_ana.append(delta_eps33_i_1)
                                        iterations.append(p+1)
                                        break

                                    #print('Trial_Stress '+str(sigma_33_trial),'Sigma_i_1 ' +str(sigma_i_1), 'Equivalent Plastic Strain: '+str(Delta_pl))
                                    



                                elif p==0:

        #                             a1r, b1r, c1r, d1r, e1r, f1r     =   ML.tens_to_voigt(stress_dev_trial)
        #                             a2r, b2r, c2r, d2r, e2r, f2r     =   ML.tens_to_voigt(stress_back_trial)
        #                             trial_stress.append([a1r, b1r, c1r, d1r, e1r, f1r])
        #                             back_stress.append([a2r, b2r, c2r, d2r, e2r, f2r])




                                    sigma_trial_phys    = effective_to_physical(sig_tr_eff_i_1.copy(), flow_damage, 1)

                                    sigma_33_trial        = sigma_trial_phys[2][2]
                                    #mat_params, Delta_pl  = implicit_integration(mat_params, stress_eqv_trial,i,l,m,n)
                                    #Delta_pl, mat_params, q, sigma_star_N  = implicit_integration_vp_1(mat_params, i, N, timeincrement, 1, wahl, stress_eqv_trial,stress_back_trial, stress_dev_trial,l,m,n,N_dirr)
                                    #Delta_pl, mat_params, q, sigma_star_N  = implicit_integration_vp_(mat_params, i, N, timeincrement, number_of_iteration, wahl, stress_eqv_trial,stress_back_trial, stress_dev_trial,l,m,n, N_dirr)
                                    
                                    phi = stress_eqv_trial - (mat_params['stress_yield'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] + mat_params['R'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                                    
                                    positive_phi = max(float(phi), 0.0)
                                    mat_params['eps_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = (positive_phi / mat_params['stress_K'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])**N
                                    mat_params['eps_pl_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] = 1.5*mat_params['eps_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*N_dirr_eff_ph
                                    mat_params['eps_pl_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][2][2] = 0.0

                                    Delta_pl_sigma33 = mat_params['eps_pl_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*timeincrement

                                    Delta_pl, mat_params                   = integrate_explicit_viscoplastic_step(mat_params, i, N, timeincrement, number_of_iteration, wahl, stress_eqv_trial,stress_back_trial, stress_dev_trial,l,m,n, N_dirr_eff_ph)
                                    
                                    
                                    #Delta_pl_sigma33                       = mat_params['eps_pl_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*timeincrement                                                                                   
                                    #sigma_i_1                              = sigma_33_trial - (1-mat_params['D'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])*((3*mat_params['mu'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*Delta_pl*(stress_dev_trial[2][2]-stress_back_trial[2][2]))/stress_eqv_trial)
                                    
                                    sigma_eff_corr_iteration = sig_tr_eff_i_1 - mat_params['C0'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]@(tens_to_voigt(mat_params['eps_pl_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])*timeincrement)
                                    sigma_i_1 = effective_to_physical(
                                        sigma_eff_corr_iteration,
                                        flow_damage,
                                        1
                                    )[2][2]
                                    
                                    sigma_i                                = sigma_i_1
                                    delta_eps33_i_minus_1                  = mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][2] 
                                    mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][2] = -(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][0] + mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][1])
                                    #mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][2]  = 0.5*mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][1]
                                    delta_eps33_i                          = mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][2]

                            
                            
    #...............................................................Updating Variables....................................................................
                            
                            plastic_increment = mat_params['eps_pl_dot'+idx] * timeincrement
                            mat_params['eps_pl_tens'+idx] = mat_params['eps_pl_tens'+idx] + plastic_increment
                            mat_params['eps_el_tens'+idx] = mat_params['eps_el_tens'+idx] + voigt_to_tens(mat_params['delta_eps'+idx]) - plastic_increment
                            
                            a1                                                            = tens_to_voigt(mat_params['eps_pl_tens'+idx])
                            b1                                                            = tens_to_voigt(mat_params['eps_el_tens'+idx])
                            
    #                         N_dirr[0][1]= N_dirr_bef[0][1]/stress_eqv_trial
    #                         N_dirr[0][2]= N_dirr_bef[0][2]/stress_eqv_trial
    #                         N_dirr[1][0]= N_dirr_bef[1][0]/stress_eqv_trial
    #                         N_dirr[1][2]= N_dirr_bef[1][2]/stress_eqv_trial
    #                         N_dirr[2][0]= N_dirr_bef[2][0]/stress_eqv_trial
    #                         N_dirr[2][1]= N_dirr_bef[2][1]/stress_eqv_trial
                            
                            
                            #N_dirr                                                        = (stress_dev_trial-stress_back_trial)/(stress_eqv_trial)
                            #c1                                                            = ML.tens_to_voigt(N_dirr)
                            
                            #mat_params['R'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]           = mat_params['R'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] + (mat_params['b1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*(mat_params['b2'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] - mat_params['R'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]))*Delta_pl
                            
                            #print(N_dirr)                                                                                                                       
                            
                            
                            
                            
                            #Delta_D                                                       = (mat_params['D_cr'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]/(mat_params['e_r'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] - mat_params['e_d'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]))*((2/3)*(1+mat_params['pois'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])  + (3-6*mat_params['pois'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])*(sph_/J_s)**(2))*(Delta_pl)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                            #Delta_X                                                       = ((2/3)*mat_params['a'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*Delta_pl*voigt_to_tens(c1*1.5) - mat_params['s'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*mat_params['stress_back'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*Delta_pl)                                                                                                                                                                                             
                            
                            
                            #stress_to_be_removed                                          = mat_params['mu1111']*np.array([3*(Delta_pl)*(c1[0]/1), 3*(Delta_pl)*(c1[1]/1), 3*(Delta_pl)*(c1[2]/1), 1.5*(Delta_pl)*(c1[3]/1), 1.5*(Delta_pl)*(c1[4]/1), 1.5*(Delta_pl)*(c1[5]/1)])                                                                                                                       

                            mat_params['D_dot'+idx] = paper_anisotropic_damage_rate(
                                mat_params, idx, float(stress_sph), float(stress_eqv_trial),
                                mat_params['eps_pl_dot'+idx]
                            )
                            d_old = np.diag(mat_params['D'+idx])
                            d_new = np.clip(d_old + mat_params['D_dot'+idx]*timeincrement, 0.0, 0.99) if damage_enabled else np.zeros(3)
                            d_new[2] = 0.0
                            mat_params['D'+idx] = np.diag(d_new)                                                                
                            response_damage = mat_params['D'+idx] if damage_enabled else zero_damage
                            updated_flow_damage = mat_params['D'+idx] if damage_coupled else zero_damage
                            #mat_params['D'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]           = mat_params['D'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] + (mat_params['D_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*timeincrement)
                            
                            
                            
                            mat_params['stress_back'+idx] = mat_params['stress_back'+idx] + mat_params['X_dot'+idx]*timeincrement
                            
                            #mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]    = (1-mat_params['D'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])*mat_params['C'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].dot(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] - tens_to_voigt(mat_params['eps_pl_dot'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])*timeincrement) + mat_params['stress_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]
                            
                            sigma_eff_corr = sig_tr_eff_i_1 - mat_params['C0'+idx]@(tens_to_voigt(mat_params['eps_pl_dot'+idx])*timeincrement)
                            mat_params['stress_n'+idx]    = effective_to_physical(sigma_eff_corr, updated_flow_damage, 1)
                            response_stress = effective_to_physical(sigma_eff_corr, response_damage, 1)

                            #mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]    = mat_params['stress_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]       +     (1-mat_params['D'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])*(mat_params['C'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].dot(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] - tens_to_voigt(1.5*Delta_pl*N_dirr)))
                            
                            #mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]    = mat_params['stress_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]  +  mat_params['C'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].dot(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]) - 3*mat_params['mu'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*Delta_pl*c1
                                        
                            #mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]    = ML.tens_to_voigt(stress_dev_trial + stress_sph) - stress_to_be_removed
                            if t % history_stride == 0:
                                mat_params['abs_strain'+idx].append(tens_to_voigt(mat_params['eps_el_tens'+idx] + mat_params['eps_pl_tens'+idx]))
                                mat_params['abs_stress'+idx].append(tens_to_voigt(response_stress))
                            #print('Wir befinden uns im Nicht-Linearen bereich des Zeitinkrements: '+str(t+1))
                            mat_params['EQPLAS'+idx]      = np.sqrt(np.tensordot(mat_params['eps_pl_tens'+idx], mat_params['eps_pl_tens'+idx], axes=2) * (2.0/3.0))
                            
                            
                            stress_dev_up, stress_sph_                                  = split(physical_to_effective(mat_params['stress_n'+idx], updated_flow_damage, 1)) 
                            
                            stress_eqv_up                                                 = np.sqrt(1.5*(np.tensordot(stress_dev_up-physical_to_effective(mat_params['stress_back'+idx], updated_flow_damage, 1), stress_dev_up-physical_to_effective(mat_params['stress_back'+idx], updated_flow_damage, 1))))    
                            
                            stress_sph_up                                                 = stress_sph_
                            ##updated as per effective stress for anisotropic consideration
                            mat_params['eps_dot'+idx]     = (max(float(phi), 0.0)/mat_params['stress_K'+idx])**(N)
                            
                            #N_dirr                                                        = (stress_dev_up-mat_params['stress_back'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])/stress_eqv_up
                            
                            mat_params['eps_pl_dot'+idx]  = 1.5*(mat_params['eps_dot'+idx])*N_dirr_eff_ph
                            mat_params['eps_pl_dot'+idx][2][2] = 0.0
                            
                            mat_params['X_dot'+idx]       = ((2/3)*mat_params['a'+idx]*mat_params['eps_pl_dot'+idx] - mat_params['s'+idx]*mat_params['stress_back'+idx]*mat_params['eps_dot'+idx])
                            
                            mat_params['D_dot'+idx]       = paper_anisotropic_damage_rate(
                                mat_params, idx, float(stress_sph_up), float(stress_eqv_up),
                                mat_params['eps_pl_dot'+idx]
                            )
                            #mat_params['stress_n1111'][2]                                     = 0
                            #mat_params['stress_back1111'][2][2]                               = 0 
                            training_data.append([mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][0], mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][1], Delta_pl_sigma33[2][2], mat_params['D'+str(i+1)+str(l+1)+str(m+1)+str(n+1)], mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][2]])

                            
                        else:
                            
                            mat_params['eps_el_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]        = mat_params['eps_el_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] + voigt_to_tens(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                            #mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]           = mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]  + (mat_params['C'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]*(1)).dot(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                            #print(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])

                            Delta_sigma_eff_voigt = mat_params['C'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].dot(mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])
                            Delta_sigma_flow = effective_to_physical(Delta_sigma_eff_voigt, flow_damage, 1)
                            mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]           =voigt_to_tens(mat_params['stress_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]) + Delta_sigma_flow
                            response_stress = effective_to_physical(
                                tens_to_voigt(mat_params['stress_n'+idx]),
                                mat_params['D'+idx] if damage_enabled else zero_damage,
                                1
                            )
                            
                            #mat_params['stress_n'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]           = mat_params['C0'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].dot((mat_params['delta_eps'+str(i+1)+str(l+1)+str(m+1)+str(n+1)])) + tens_to_voigt(mat_params['stress_n-1'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]) 
                            mat_params['stress_eqv_trial'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]   = stress_eqv_trial
                            mat_params['C_ep'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]               = mat_params['C'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].copy()
                            if t % history_stride == 0:
                                mat_params['abs_strain'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].append(tens_to_voigt(mat_params['eps_el_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)] + mat_params['eps_pl_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)]))
                                mat_params['abs_stress'+str(i+1)+str(l+1)+str(m+1)+str(n+1)].append(tens_to_voigt(response_stress))
                            eps33_ana.append(mat_params['eps_el_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][2][2] + mat_params['eps_pl_tens'+str(i+1)+str(l+1)+str(m+1)+str(n+1)][2][2])
                            #print(mat_params['stress_n1111'])
                            #print('Wir befinden uns im Linearen bereich des Zeitinkrements: '+str(t+1))
                            #count_tr = 0
                                                                                                                                                            
                                                                                                                                                

            
            





    #np.savetxt(r'D:\Ameya\IAM-HIWI\Material_model\Saurabh_files\iterations.csv', np.array(iterations), delimiter=',')



    if plot:
        fig = plt.figure(figsize=(12,9))
        ax = fig.add_subplot(111)
        ax.plot(np.array(mat_params['abs_strain1111'])[:,0:1], np.array(mat_params['abs_stress1111'])[:,0:1], label=r'$\sigma_{11} mit Schaedigung$')
        ax.plot(np.array(mat_params['abs_strain1111'])[:,1:2], np.array(mat_params['abs_stress1111'])[:,1:2], label=r'Stress2 mit Schaedigung')
        ax.plot(np.array(mat_params['abs_strain1111'])[:,2:3], np.array(mat_params['abs_stress1111'])[:,2:3], label=r'Stress3 mit Schaedigung')
        ax.plot(np.array(mat_params['abs_strain1111'])[:,3:4], np.array(mat_params['abs_stress1111'])[:,3:4], label=r'$\sigma_{23}$ mit Schaedigung')
        ax.plot(np.array(mat_params['abs_strain1111'])[:,4:5], np.array(mat_params['abs_stress1111'])[:,4:5], label=r'$\sigma_{13}$ mit Schaedigung')
        ax.plot(np.array(mat_params['abs_strain1111'])[:,5:6], np.array(mat_params['abs_stress1111'])[:,5:6], label=r'$\sigma_{12}$ mit Schaedigung')
        plt.xlabel('Dehnung')
        plt.ylabel('Spannung')
        plt.legend()
        plt.savefig(save_path or 'Stress_Strain_curve.png', dpi=200, bbox_inches="tight")
        if show:
            plt.show()
        plt.close(fig)

    if save_path and not plot:
        np.savetxt(save_path, np.column_stack((mat_params['abs_strain1111'], mat_params['abs_stress1111'])), delimiter=',')
    return mat_params





if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path", help="Path to input CSV")
    args = parser.parse_args()
    run_explicit_anisotropic_simulation(args.csv_path)
