"""Automatic-differentiation implicit anisotropic-damage material model."""

from __future__ import annotations

import numpy as np
import torch

# The batched constitutive core is included alongside this module.
import batched_anisotropic_damage_core as _base


DTYPE = _base.DTYPE
NEWTON_TOL = _base.NEWTON_TOL
NEWTON_MAX_ITER = _base.NEWTON_MAX_ITER
MATERIAL_PARAMETERS = {
    "E_default": 67400.0,
    "yield_default": 30.0,
    "pois": 0.32,
    "timeincrement": 1.0,
    "N": 2.79,
    "stress_K": 3.42,
    "a_unit": 3100.0,
    "s_unit": 110.0,
    "a": 98939.3,
    "s": 1533.41,
    "D_cr": 0.22,
    "e_d": 0.0,
    "e_r": 0.16296296296296295,
}


def initialize_batch_state(num_points: int, device: torch.device) -> dict:
    """Initialize the material-point state with the configured properties."""
    state = _base.initialize_batch_state(num_points, device)
    C0_np, _, mu = _base.elastic_stiffness(MATERIAL_PARAMETERS["E_default"], MATERIAL_PARAMETERS["pois"])
    C0 = torch.as_tensor(C0_np, dtype=DTYPE, device=device)
    params = state["params"]
    values = {
        "timeincrement": MATERIAL_PARAMETERS["timeincrement"], "N": MATERIAL_PARAMETERS["N"],
        "stress_yield": MATERIAL_PARAMETERS["yield_default"], "stress_K": MATERIAL_PARAMETERS["stress_K"],
        "mu": mu, "pois": MATERIAL_PARAMETERS["pois"], "a_unit": MATERIAL_PARAMETERS["a_unit"],
        "s_unit": MATERIAL_PARAMETERS["s_unit"], "a": MATERIAL_PARAMETERS["a"], "s": MATERIAL_PARAMETERS["s"],
        "D_cr": MATERIAL_PARAMETERS["D_cr"], "e_d": MATERIAL_PARAMETERS["e_d"], "e_r": MATERIAL_PARAMETERS["e_r"],
    }
    for key, value in values.items():
        params[key] = torch.as_tensor(value, dtype=DTYPE, device=device)
    params["C0"] = C0
    params["C0_inplane"] = C0[[0, 1, 5]][:, [0, 1, 5]]
    state["C_ep"] = C0.unsqueeze(0).repeat(num_points, 1, 1).clone()
    Cps = elastic_plane_stress_tangent_batched(C0)
    state["C_ep_ps"] = Cps.unsqueeze(0).repeat(num_points, 1, 1).clone()
    return state


def _run_single_point(delta_eps6: np.ndarray, steps: int) -> list[str]:
    state = initialize_batch_state(1, torch.device("cpu"))
    delta = torch.as_tensor(np.asarray(delta_eps6, dtype=float).reshape(1, 6), dtype=DTYPE)
    statuses = []
    for _ in range(steps):
        state, result = update_material_points_gpu(state, delta)
        statuses.append("elastic" if int(result["status_code"][0]) == 0 else "plastic")
    return statuses


def find_common_increment_for_split(elastic_steps: int, plastic_steps: int, *, direction: np.ndarray | None = None,
                                    scale_min: float = 1e-8, scale_max: float = 5e-3, num_scales: int = 100) -> np.ndarray:
    """Select an increment that produces elastic and plastic response groups."""
    base = np.asarray([1., 0., 0., 0., 0., 0.] if direction is None else direction, dtype=float).reshape(6)
    base /= np.linalg.norm(base)
    for scale in np.geomspace(scale_min, scale_max, num_scales):
        delta = scale * base
        elastic = _run_single_point(delta, elastic_steps)
        plastic = _run_single_point(delta, plastic_steps)
        if all(status == "elastic" for status in elastic) and any(status == "plastic" for status in plastic):
            return delta
    raise RuntimeError("Unable to find a common elastic/plastic increment for the configured material parameters.")


def elastic_plane_stress_tangent_batched(C0: torch.Tensor) -> torch.Tensor:
    """Condense 3D C0 to [11, 22, 12] under sigma33 = 0.

    The full Voigt order is [11, 22, 33, 23, 13, 12].  The retained in-plane
    indices are [0, 1, 5], and the solved out-of-plane normal strain is index 2.
    The remaining shear components are uncoupled for the isotropic C0 used by
    the model, so this is the exact derivative of its elastic plane-stress update.
    """
    inplane = torch.as_tensor([0, 1, 5], dtype=torch.long, device=C0.device)
    normal = torch.as_tensor([2], dtype=torch.long, device=C0.device)
    Caa = C0.index_select(0, inplane).index_select(1, inplane)
    Ca3 = C0.index_select(0, inplane).index_select(1, normal)
    C3a = C0.index_select(0, normal).index_select(1, inplane)
    C33 = C0.index_select(0, normal).index_select(1, normal)
    return Caa - Ca3 @ torch.linalg.solve(C33, C3a)


def update_material_points_gpu(batch_state: dict, delta_eps6_batch: torch.Tensor) -> tuple[dict, dict]:
    """Return one C_ep_ps per point, selected internally by active branch."""
    batch_state, result = _base.update_material_points_gpu(batch_state, delta_eps6_batch)
    elastic_mask = result["status_code"] == 0
    if torch.any(elastic_mask):
        Cps_elastic = elastic_plane_stress_tangent_batched(batch_state["params"]["C0"])
        batch_state["C_ep_ps"][elastic_mask] = Cps_elastic.unsqueeze(0).expand(
            int(torch.sum(elastic_mask).item()), -1, -1
        )
    return batch_state, result


def __getattr__(name: str):
    """Expose the batched model interface to existing callers."""
    return getattr(_base, name)
