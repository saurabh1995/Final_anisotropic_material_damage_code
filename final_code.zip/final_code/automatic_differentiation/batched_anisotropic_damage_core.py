"""
Batched GPU constitutive update for implicit anisotropic viscoplastic damage.

The local update is expressed with batched PyTorch operations:
- batched state tensors with leading Gauss-point dimension
- batched elastic predictor and trial-yield classification
- batched local Newton solve for plastic points
- batched AD-based consistent tangent calculation
"""

from __future__ import annotations

import argparse
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mplconfig")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.func import jacfwd, vmap

ROOT = Path(__file__).resolve().parents[2]


DTYPE = torch.float64
SIGMA33_TOL = 1e-8
EQPLAS_ZERO_TOL = 1e-12
DP_ZERO_TOL = 1e-14
COMPARE_RTOL = 1e-7
COMPARE_ATOL = 1e-9
NEWTON_TOL = 1e-10
NEWTON_MAX_ITER = 40
ELASTIC_EPS33_TOL = 1e-12
ELASTIC_EPS33_MAX_ITER = 30
DEFAULT_POIS = 0.30
DEFAULT_TIMEINCREMENT = 1e-6
DEFAULT_N = 8.15
DEFAULT_E = 113066.0
DEFAULT_YIELD = 180.0
DEFAULT_STRESS_K = 11.45
DEFAULT_A_UNIT = 11000.0
DEFAULT_S_UNIT = 110.0
DEFAULT_A = 98939.30
DEFAULT_S = 1533.41
DEFAULT_D_CR = 0.22
DEFAULT_E_D = 0.0
DEFAULT_E_R = 0.16296296296296295


@dataclass
class BatchConfig:
    num_points: int = 20
    num_elastic_points: int = 10
    num_plastic_points: int = 10
    elastic_steps: int = 1
    plastic_steps: int = 5
    delta_eps6: np.ndarray | None = None
    device: str | None = None
    allow_cpu_fallback: bool = False
    auto_search_increment: bool = False


def _set_runtime_env() -> None:
    os.environ.setdefault("MPLCONFIGDIR", "/tmp/mplconfig")


def resolve_device(device: str | None = None, allow_cpu_fallback: bool = False) -> torch.device:
    if device is None:
        if torch.cuda.is_available():
            return torch.device("cuda")
        if allow_cpu_fallback:
            return torch.device("cpu")
        raise RuntimeError(
            "CUDA is not available. Pass allow_cpu_fallback=True or set device='cpu' for debugging."
        )

    resolved = torch.device(device)
    if resolved.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError(f"Requested CUDA device '{device}' but CUDA is not available.")
    if resolved.type == "cpu" and not allow_cpu_fallback:
        raise RuntimeError(
            "CPU execution is only intended for debugging here. Pass allow_cpu_fallback=True to allow it."
        )
    return resolved


def _normalize_direction(direction: np.ndarray) -> np.ndarray:
    direction = np.asarray(direction, dtype=float).reshape(6)
    norm = np.linalg.norm(direction)
    if norm <= 0.0:
        raise ValueError("direction must have nonzero norm")
    return direction / norm


def props_update(E: float, pois: float) -> tuple[float, float]:
    lam = (E * pois) / ((1.0 + pois) * (1.0 - 2.0 * pois))
    mu = 0.5 * E / (1.0 + pois)
    return lam, mu


def elastic_stiffness(E: float, pois: float) -> tuple[np.ndarray, float, float]:
    lam, mu = props_update(E, pois)
    aa = 2.0 * mu + lam
    C = np.array([
        [aa, lam, lam, 0.0, 0.0, 0.0],
        [lam, aa, lam, 0.0, 0.0, 0.0],
        [lam, lam, aa, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, mu, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, mu, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, mu],
    ], dtype=float)
    return C, lam, mu


def tens_to_voigt_np(T: np.ndarray) -> np.ndarray:
    return np.array([T[0, 0], T[1, 1], T[2, 2], T[1, 2], T[0, 2], T[0, 1]], dtype=float)


def _single_point_state_to_numpy(batch_state: dict) -> dict:
    return {
        "stress_n": batch_state["stress_n"][0].detach().cpu().numpy(),
        "stress_back": batch_state["stress_back"][0].detach().cpu().numpy(),
        "D": batch_state["D"][0].detach().cpu().numpy(),
        "EQPLAS": float(batch_state["EQPLAS"][0].detach().cpu().item()),
        "Delta_pl": float(batch_state["Delta_pl"][0].detach().cpu().item()),
        "C_ep": batch_state["C_ep"][0].detach().cpu().numpy(),
        "C_ep_ps": batch_state["C_ep_ps"][0].detach().cpu().numpy(),
    }


def _run_single_point(delta_eps6: np.ndarray, steps: int) -> tuple[dict, list[str]]:
    device = torch.device("cpu")
    mat = initialize_batch_state(1, device)
    delta = torch.as_tensor(np.asarray(delta_eps6, dtype=float).reshape(1, 6), dtype=DTYPE, device=device)
    statuses = []
    for _ in range(steps):
        mat, result = update_material_points_gpu(mat, delta)
        code = int(result["status_code"][0].detach().cpu().item())
        statuses.append("elastic" if code == 0 else "plastic" if code == 1 else "unknown")
    return _single_point_state_to_numpy(mat), statuses


def find_common_increment_for_split(
    elastic_steps: int,
    plastic_steps: int,
    *,
    direction: np.ndarray | None = None,
    scale_min: float = 1e-8,
    scale_max: float = 5e-3,
    num_scales: int = 100,
) -> np.ndarray:
    if elastic_steps < 0 or plastic_steps < 1:
        raise ValueError("elastic_steps must be >= 0 and plastic_steps must be >= 1")
    if plastic_steps <= elastic_steps:
        raise ValueError("plastic_steps must be greater than elastic_steps")

    base_direction = _normalize_direction(
        np.array([1.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=float) if direction is None else direction
    )

    for scale in np.geomspace(scale_min, scale_max, num_scales):
        delta = scale * base_direction
        _, elastic_statuses = _run_single_point(delta, elastic_steps)
        _, plastic_statuses = _run_single_point(delta, plastic_steps)
        if all(status == "elastic" for status in elastic_statuses) and any(
            status == "plastic" for status in plastic_statuses
        ):
            return delta

    raise RuntimeError(
        "Unable to find a common increment that keeps the elastic group elastic "
        "and drives the plastic group into plasticity. Try different step counts."
    )


def _make_base_params(device: torch.device) -> dict:
    C0, _, mu = elastic_stiffness(DEFAULT_E, DEFAULT_POIS)
    params = {
        "timeincrement": torch.as_tensor(DEFAULT_TIMEINCREMENT, dtype=DTYPE, device=device),
        "N": torch.as_tensor(DEFAULT_N, dtype=DTYPE, device=device),
        "stress_yield": torch.as_tensor(DEFAULT_YIELD, dtype=DTYPE, device=device),
        "stress_K": torch.as_tensor(DEFAULT_STRESS_K, dtype=DTYPE, device=device),
        "mu": torch.as_tensor(mu, dtype=DTYPE, device=device),
        "pois": torch.as_tensor(DEFAULT_POIS, dtype=DTYPE, device=device),
        "a_unit": torch.as_tensor(DEFAULT_A_UNIT, dtype=DTYPE, device=device),
        "s_unit": torch.as_tensor(DEFAULT_S_UNIT, dtype=DTYPE, device=device),
        "a": torch.as_tensor(DEFAULT_A, dtype=DTYPE, device=device),
        "s": torch.as_tensor(DEFAULT_S, dtype=DTYPE, device=device),
        "D_cr": torch.as_tensor(DEFAULT_D_CR, dtype=DTYPE, device=device),
        "e_d": torch.as_tensor(DEFAULT_E_D, dtype=DTYPE, device=device),
        "e_r": torch.as_tensor(DEFAULT_E_R, dtype=DTYPE, device=device),
        "C0": torch.as_tensor(C0, dtype=DTYPE, device=device),
    }
    params["C0_inplane"] = params["C0"][[0, 1, 5]][:, [0, 1, 5]]
    return params


def initialize_batch_state(num_points: int, device: torch.device) -> dict:
    if num_points <= 0:
        raise ValueError("num_points must be positive")
    params = _make_base_params(device)
    eye = torch.eye(3, dtype=DTYPE, device=device)
    _ = eye  # keeps intent explicit for future extensions
    return {
        "stress_n": torch.zeros((num_points, 3, 3), dtype=DTYPE, device=device),
        "stress_back": torch.zeros((num_points, 3, 3), dtype=DTYPE, device=device),
        "D": torch.zeros((num_points, 3, 3), dtype=DTYPE, device=device),
        "eps_pl_tens": torch.zeros((num_points, 3, 3), dtype=DTYPE, device=device),
        "eps_el_tens": torch.zeros((num_points, 3, 3), dtype=DTYPE, device=device),
        "EQPLAS": torch.zeros((num_points,), dtype=DTYPE, device=device),
        "Delta_pl": torch.zeros((num_points,), dtype=DTYPE, device=device),
        "C_ep": params["C0"].unsqueeze(0).repeat(num_points, 1, 1).clone(),
        "C_ep_ps": params["C0_inplane"].unsqueeze(0).repeat(num_points, 1, 1).clone(),
        "last_status_code": torch.full((num_points,), -1, dtype=torch.int64, device=device),
        "params": params,
    }


def voigt_to_tens_b(v: torch.Tensor) -> torch.Tensor:
    if v.ndim == 1:
        v = v.unsqueeze(0)
    row0 = torch.stack([v[:, 0], v[:, 5], v[:, 4]], dim=1)
    row1 = torch.stack([v[:, 5], v[:, 1], v[:, 3]], dim=1)
    row2 = torch.stack([v[:, 4], v[:, 3], v[:, 2]], dim=1)
    return torch.stack([row0, row1, row2], dim=1)


def tens_to_voigt_b(T: torch.Tensor) -> torch.Tensor:
    if T.ndim == 2:
        T = T.unsqueeze(0)
    return torch.stack(
        [T[:, 0, 0], T[:, 1, 1], T[:, 2, 2], T[:, 1, 2], T[:, 0, 2], T[:, 0, 1]],
        dim=1,
    )


def dev_b(T: torch.Tensor) -> torch.Tensor:
    tr = torch.einsum("bii->b", T)
    I = torch.eye(3, dtype=T.dtype, device=T.device).unsqueeze(0).expand(T.shape[0], -1, -1)
    return T - I * (tr / 3.0).view(-1, 1, 1)


def split_b(T: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    hyd = torch.einsum("bii->b", T) / 3.0
    return dev_b(T), hyd


def ddot_b(A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
    return torch.sum(A * B, dim=(1, 2))


def diag_from_damage_vec_b(dvec: torch.Tensor) -> torch.Tensor:
    d = torch.clamp(dvec, min=0.0, max=0.99)
    return torch.diag_embed(d)


def damage_scalar_mean_b(D: torch.Tensor) -> torch.Tensor:
    return torch.diagonal(D, dim1=-2, dim2=-1).mean(dim=-1)


def damage_multiplier_b(D: torch.Tensor) -> torch.Tensor:
    d = torch.clamp(torch.diagonal(D, dim1=-2, dim2=-1), min=0.0, max=0.99)
    return torch.diag_embed(1.0 / torch.sqrt(1.0 - d))


def damage_multiplier_inverse_b(D: torch.Tensor) -> torch.Tensor:
    d = torch.clamp(torch.diagonal(D, dim1=-2, dim2=-1), min=0.0, max=0.99)
    return torch.diag_embed(torch.sqrt(1.0 - d))


def physical_to_effective_b(sigma: torch.Tensor, D: torch.Tensor) -> torch.Tensor:
    dev, hyd = split_b(sigma)
    H = damage_multiplier_b(D)
    D_H = damage_scalar_mean_b(D)
    sigma_dev = H @ dev @ H
    I = torch.eye(3, dtype=sigma.dtype, device=sigma.device).unsqueeze(0).expand(sigma.shape[0], -1, -1)
    return sigma_dev + (hyd / (1.0 - D_H + 1e-30)).view(-1, 1, 1) * I


def effective_to_physical_b(sigma: torch.Tensor, D: torch.Tensor) -> torch.Tensor:
    Hinv = damage_multiplier_inverse_b(D)
    D_H = damage_scalar_mean_b(D)
    I = torch.eye(3, dtype=sigma.dtype, device=sigma.device).unsqueeze(0).expand(sigma.shape[0], -1, -1)
    B = Hinv @ sigma @ Hinv
    Hinv2 = Hinv @ Hinv
    p_phys = (1.0 - D_H) * torch.einsum("bii->b", B) / (torch.einsum("bii->b", Hinv2) + 1e-30)
    s_phys = Hinv @ (sigma - (p_phys / (1.0 - D_H + 1e-30)).view(-1, 1, 1) * I) @ Hinv
    return s_phys + p_phys.view(-1, 1, 1) * I


def make_delta_eps_b(delta_eps6: torch.Tensor, eps33: torch.Tensor) -> torch.Tensor:
    return torch.stack(
        [delta_eps6[:, 0], delta_eps6[:, 1], eps33, delta_eps6[:, 3], delta_eps6[:, 4], delta_eps6[:, 5]],
        dim=1,
    )


def local_response_batched(xvec: torch.Tensor, delta_eps6: torch.Tensor, state_old: dict, params: dict) -> tuple[torch.Tensor, dict]:
    eps33 = xvec[:, 0]
    dp = torch.clamp(xvec[:, 1], min=1e-14)
    dvec = xvec[:, 2:5]

    dt = params["timeincrement"]
    C0 = params["C0"]
    sigy = params["stress_yield"]
    K = params["stress_K"]
    Nrate = params["N"]
    mu = params["mu"]
    nu = params["pois"]
    a_unit = params["a_unit"]
    s_unit = params["s_unit"]
    D_cr = params["D_cr"]
    e_d = params["e_d"]
    e_r = params["e_r"]

    sigma_old_phys = state_old["stress_n"]
    back_old_phys = state_old["stress_back"]
    D_old = state_old["D"]

    D_new = diag_from_damage_vec_b(dvec)
    delta_eps = make_delta_eps_b(delta_eps6, eps33)

    sigma_old_eff = physical_to_effective_b(sigma_old_phys, D_old)
    sig_eff_tr6 = tens_to_voigt_b(sigma_old_eff) + delta_eps @ C0.T
    sig_eff_tr = voigt_to_tens_b(sig_eff_tr6)
    s_eff_tr = dev_b(sig_eff_tr)

    back_old_phys_pred = back_old_phys / (1.0 + s_unit * dp + 1e-30).view(-1, 1, 1)
    back_old_eff_pred = physical_to_effective_b(back_old_phys_pred, D_old)
    zeta = s_eff_tr - back_old_eff_pred
    J = torch.sqrt(1.5 * ddot_b(zeta, zeta) + 1e-30)
    N_eff = zeta / J.view(-1, 1, 1)

    h = sigy + K * (dp / dt) ** (1.0 / Nrate)
    alpha = 1.0 + (3.0 * mu + (a_unit / (1.0 + s_unit * dp))) * (dp / h)
    R_vp = (J / alpha) - h

    N_phys = effective_to_physical_b(N_eff, D_new)
    dep_tens = 1.5 * dp.view(-1, 1, 1) * N_phys
    eps_pl_dot = dep_tens / dt

    sig_eff_corr6 = sig_eff_tr6 - tens_to_voigt_b(dep_tens) @ C0.T
    sig_eff_corr = voigt_to_tens_b(sig_eff_corr6)
    sigma_new_phys = effective_to_physical_b(sig_eff_corr, D_new)

    back_new_phys = (back_old_phys + a_unit * dp.view(-1, 1, 1) * N_phys) / (
        1.0 + s_unit * dp + 1e-30
    ).view(-1, 1, 1)
    back_new_eff = physical_to_effective_b(back_new_phys, D_new)

    s_eff_new, hyd_eff_new = split_b(sig_eff_corr)
    zeta_new = s_eff_new - back_new_eff
    seq_eff_new = torch.sqrt(1.5 * ddot_b(zeta_new, zeta_new) + 1e-30)

    damage_prefactor = D_cr / (e_r - e_d + 1e-30)
    damage_prefactor = damage_prefactor * (
        (2.0 / 3.0) * (1.0 + nu)
        + (3.0 - 6.0 * nu) * (hyd_eff_new / (seq_eff_new + 1e-30)) ** 2
    )
    eps_pl_dot_diag = torch.abs(torch.diagonal(eps_pl_dot, dim1=-2, dim2=-1))
    D_target = torch.diagonal(D_old, dim1=-2, dim2=-1) + dt * damage_prefactor.view(-1, 1) * eps_pl_dot_diag

    R_sigma33 = sigma_new_phys[:, 2, 2]
    R_damage = torch.diagonal(D_new, dim1=-2, dim2=-1) - D_target
    residual = torch.cat([torch.stack([R_sigma33, R_vp], dim=1), R_damage], dim=1)

    aux = {
        "delta_eps": delta_eps,
        "sigma_new_phys": sigma_new_phys,
        "sigma_new_eff": sig_eff_corr,
        "back_new_phys": back_new_phys,
        "dep_tens": dep_tens,
        "D_new": D_new,
    }
    return residual, aux


def elastic_plane_stress_eps33_batched(delta_eps6: torch.Tensor, state_old: dict, params: dict) -> torch.Tensor:
    eps33 = -(delta_eps6[:, 0] + delta_eps6[:, 1])
    sigma_old_eff = physical_to_effective_b(state_old["stress_n"], state_old["D"])
    C0 = params["C0"]
    D_old = state_old["D"]

    for _ in range(ELASTIC_EPS33_MAX_ITER):
        de = make_delta_eps_b(delta_eps6, eps33)
        sigma_eff_new = voigt_to_tens_b(tens_to_voigt_b(sigma_old_eff) + de @ C0.T)
        sigma_phys_new = effective_to_physical_b(sigma_eff_new, D_old)
        r = sigma_phys_new[:, 2, 2]
        if torch.max(torch.abs(r)) < ELASTIC_EPS33_TOL:
            break
        h = 1e-8
        de_h = make_delta_eps_b(delta_eps6, eps33 + h)
        sigma_eff_h = voigt_to_tens_b(tens_to_voigt_b(sigma_old_eff) + de_h @ C0.T)
        sigma_phys_h = effective_to_physical_b(sigma_eff_h, D_old)
        dr = (sigma_phys_h[:, 2, 2] - r) / h
        eps33 = eps33 - r / (dr + 1e-30)
    return eps33


def trial_yield_function_batched(delta_eps6: torch.Tensor, eps33: torch.Tensor, state_old: dict, params: dict) -> tuple[torch.Tensor, torch.Tensor]:
    de = make_delta_eps_b(delta_eps6, eps33)
    sigma_old_eff = physical_to_effective_b(state_old["stress_n"], state_old["D"])
    back_old_eff = physical_to_effective_b(state_old["stress_back"], state_old["D"])
    sig_eff_tr = voigt_to_tens_b(tens_to_voigt_b(sigma_old_eff) + de @ params["C0"].T)
    s_eff_tr, _ = split_b(sig_eff_tr)
    zeta = s_eff_tr - back_old_eff
    seq = torch.sqrt(torch.clamp(1.5 * ddot_b(zeta, zeta), min=0.0))
    return seq - params["stress_yield"], seq


def _single_residual_for_jac(x_single: torch.Tensor, delta_single: torch.Tensor, state_old_single: dict, params: dict) -> torch.Tensor:
    x_batch = x_single.unsqueeze(0)
    delta_batch = delta_single.unsqueeze(0)
    state_batch = {k: v.unsqueeze(0) if torch.is_tensor(v) and v.ndim > 0 else v for k, v in state_old_single.items()}
    return local_response_batched(x_batch, delta_batch, state_batch, params)[0].squeeze(0)


def _single_stress_voigt_for_tangent(
    x_single: torch.Tensor,
    delta_single: torch.Tensor,
    state_old_single: dict,
    params: dict,
) -> torch.Tensor:
    x_batch = x_single.unsqueeze(0)
    delta_batch = delta_single.unsqueeze(0)
    state_batch = {k: v.unsqueeze(0) if torch.is_tensor(v) and v.ndim > 0 else v for k, v in state_old_single.items()}
    _, aux = local_response_batched(x_batch, delta_batch, state_batch, params)
    return tens_to_voigt_b(aux["sigma_new_phys"]).squeeze(0)


def plane_stress_tangent_batched(
    x_batch: torch.Tensor,
    delta_eps6_batch: torch.Tensor,
    state_old_batch: dict,
    params: dict,
) -> tuple[torch.Tensor, torch.Tensor]:
    jac_x_fn = jacfwd(
        lambda x_single, delta_single, state_single: _single_residual_for_jac(
            x_single, delta_single, state_single, params
        ),
        argnums=0,
    )
    jac_eps_fn = jacfwd(
        lambda x_single, delta_single, state_single: _single_residual_for_jac(
            x_single, delta_single, state_single, params
        ),
        argnums=1,
    )
    stress_x_fn = jacfwd(
        lambda x_single, delta_single, state_single: _single_stress_voigt_for_tangent(
            x_single, delta_single, state_single, params
        ),
        argnums=0,
    )
    stress_eps_fn = jacfwd(
        lambda x_single, delta_single, state_single: _single_stress_voigt_for_tangent(
            x_single, delta_single, state_single, params
        ),
        argnums=1,
    )

    A = vmap(jac_x_fn)(x_batch, delta_eps6_batch, state_old_batch)
    B = vmap(jac_eps_fn)(x_batch, delta_eps6_batch, state_old_batch)
    Sx = vmap(stress_x_fn)(x_batch, delta_eps6_batch, state_old_batch)
    Se = vmap(stress_eps_fn)(x_batch, delta_eps6_batch, state_old_batch)

    eye = torch.eye(A.shape[-1], dtype=DTYPE, device=A.device).unsqueeze(0).expand(A.shape[0], -1, -1)
    dx_de = -torch.linalg.solve(A + 1e-14 * eye, B)
    full = Se + torch.matmul(Sx, dx_de)
    inplane_ids = torch.as_tensor([0, 1, 5], dtype=torch.long, device=A.device)
    Cep = full.index_select(1, inplane_ids).index_select(2, inplane_ids)
    return Cep, full


def solve_local_newton_batched(delta_eps6: torch.Tensor, state_old: dict, params: dict) -> dict:
    num_points = delta_eps6.shape[0]
    eps33_guess = elastic_plane_stress_eps33_batched(delta_eps6, state_old, params)
    phi_trial, seq_trial = trial_yield_function_batched(delta_eps6, eps33_guess, state_old, params)
    plastic_mask = phi_trial > 0.0
    elastic_mask = ~plastic_mask

    result = {
        "status_code": torch.full((num_points,), -1, dtype=torch.int64, device=delta_eps6.device),
        "x": torch.zeros((num_points, 5), dtype=DTYPE, device=delta_eps6.device),
        "sigma_new_phys": torch.zeros((num_points, 3, 3), dtype=DTYPE, device=delta_eps6.device),
        "sigma_new_eff": torch.zeros((num_points, 3, 3), dtype=DTYPE, device=delta_eps6.device),
        "back_new_phys": state_old["stress_back"].clone(),
        "dep_tens": torch.zeros((num_points, 3, 3), dtype=DTYPE, device=delta_eps6.device),
        "D_new": state_old["D"].clone(),
        "delta_eps": torch.zeros((num_points, 6), dtype=DTYPE, device=delta_eps6.device),
        "phi_trial": phi_trial,
        "seq_trial": seq_trial,
        "iters": torch.zeros((num_points,), dtype=torch.int64, device=delta_eps6.device),
        "res_norm": torch.zeros((num_points,), dtype=DTYPE, device=delta_eps6.device),
    }

    if torch.any(elastic_mask):
        idx = torch.nonzero(elastic_mask, as_tuple=False).flatten()
        de = make_delta_eps_b(delta_eps6[idx], eps33_guess[idx])
        sigma_old_eff = physical_to_effective_b(state_old["stress_n"][idx], state_old["D"][idx])
        sigma_eff_new = voigt_to_tens_b(tens_to_voigt_b(sigma_old_eff) + de @ params["C0"].T)
        sigma_phys_new = effective_to_physical_b(sigma_eff_new, state_old["D"][idx])
        result["status_code"][idx] = 0
        result["x"][idx, 0] = eps33_guess[idx]
        result["x"][idx, 2:5] = torch.diagonal(state_old["D"][idx], dim1=-2, dim2=-1)
        result["sigma_new_phys"][idx] = sigma_phys_new
        result["sigma_new_eff"][idx] = sigma_eff_new
        result["delta_eps"][idx] = de

    if not torch.any(plastic_mask):
        return result

    idx = torch.nonzero(plastic_mask, as_tuple=False).flatten()
    delta_p = delta_eps6[idx]
    state_p = {k: v[idx] if torch.is_tensor(v) else v for k, v in state_old.items()}
    phi_p = phi_trial[idx]
    D_old_diag = torch.diagonal(state_p["D"], dim1=-2, dim2=-1)
    dp0 = torch.maximum(
        torch.full_like(phi_p, 1e-10),
        ((torch.clamp(phi_p, min=1e-12) / params["stress_K"]) ** params["N"]) * params["timeincrement"],
    )
    x = torch.cat([eps33_guess[idx].unsqueeze(1), dp0.unsqueeze(1), D_old_diag], dim=1)

    active = torch.ones((x.shape[0],), dtype=torch.bool, device=x.device)
    jac_fn = jacfwd(lambda x_single, delta_single, state_single: _single_residual_for_jac(
        x_single, delta_single, state_single, params
    ), argnums=0)

    for it in range(NEWTON_MAX_ITER):
        if not torch.any(active):
            break

        active_idx = torch.nonzero(active, as_tuple=False).flatten()
        x_active = x[active_idx]
        delta_active = delta_p[active_idx]
        state_active = {k: v[active_idx] if torch.is_tensor(v) else v for k, v in state_p.items()}

        r_active, _ = local_response_batched(x_active, delta_active, state_active, params)
        J_active = vmap(jac_fn)(x_active, delta_active, state_active)
        res_norm = torch.linalg.norm(r_active, dim=1)

        converged = res_norm < NEWTON_TOL
        orig_active_idx = active_idx
        result["iters"][idx[orig_active_idx]] = it
        result["res_norm"][idx[orig_active_idx]] = res_norm
        if torch.any(converged):
            active[orig_active_idx[converged]] = False

        if not torch.any(~converged):
            break

        unconverged_idx = orig_active_idx[~converged]
        x_work = x[unconverged_idx]
        r_work = r_active[~converged]
        J_work = J_active[~converged]
        delta_work = delta_p[unconverged_idx]
        state_work = {k: v[unconverged_idx] if torch.is_tensor(v) else v for k, v in state_p.items()}

        eye = torch.eye(5, dtype=DTYPE, device=x.device).unsqueeze(0).expand(J_work.shape[0], -1, -1)
        dx = torch.linalg.solve(J_work + 1e-14 * eye, -r_work.unsqueeze(-1)).squeeze(-1)

        best_x = x_work.clone()
        best_norm = torch.linalg.norm(r_work, dim=1)
        accepted = torch.zeros_like(best_norm, dtype=torch.bool)
        step = torch.ones_like(best_norm)

        for _ in range(10):
            x_trial = x_work + step.unsqueeze(1) * dx
            x_trial[:, 1] = torch.clamp(x_trial[:, 1], min=1e-14)
            x_trial[:, 2:5] = torch.clamp(x_trial[:, 2:5], min=0.0, max=0.99)
            r_trial = local_response_batched(x_trial, delta_work, state_work, params)[0]
            trial_norm = torch.linalg.norm(r_trial, dim=1)

            improved = trial_norm < best_norm
            best_x[improved] = x_trial[improved]
            best_norm[improved] = trial_norm[improved]

            newly_accepted = trial_norm < torch.linalg.norm(r_work, dim=1)
            x_work[newly_accepted] = x_trial[newly_accepted]
            accepted = accepted | newly_accepted

            if torch.all(accepted):
                break
            step = torch.where(accepted, step, 0.5 * step)

        x[unconverged_idx] = torch.where(accepted.unsqueeze(1), x_work, best_x)

    _, aux = local_response_batched(x, delta_p, state_p, params)
    result["status_code"][idx] = 1
    result["x"][idx] = x
    result["sigma_new_phys"][idx] = aux["sigma_new_phys"]
    result["sigma_new_eff"][idx] = aux["sigma_new_eff"]
    result["back_new_phys"][idx] = aux["back_new_phys"]
    result["dep_tens"][idx] = aux["dep_tens"]
    result["D_new"][idx] = aux["D_new"]
    result["delta_eps"][idx] = aux["delta_eps"]
    result["iters"][idx] = torch.maximum(result["iters"][idx], torch.ones_like(result["iters"][idx]))
    return result


def update_material_points_gpu(batch_state: dict, delta_eps6_batch: torch.Tensor) -> tuple[dict, dict]:
    state_old = {
        "stress_n": batch_state["stress_n"].clone(),
        "stress_back": batch_state["stress_back"].clone(),
        "D": batch_state["D"].clone(),
        "eps_pl_tens": batch_state["eps_pl_tens"].clone(),
        "eps_el_tens": batch_state["eps_el_tens"].clone(),
        "EQPLAS": batch_state["EQPLAS"].clone(),
    }
    result = solve_local_newton_batched(delta_eps6_batch, state_old, batch_state["params"])

    x = result["x"]
    dp = torch.clamp(x[:, 1], min=0.0)

    batch_state["stress_n"] = result["sigma_new_phys"]
    batch_state["stress_back"] = result["back_new_phys"]
    batch_state["D"] = result["D_new"]
    batch_state["eps_pl_tens"] = state_old["eps_pl_tens"] + result["dep_tens"]
    batch_state["eps_el_tens"] = state_old["eps_el_tens"] + voigt_to_tens_b(result["delta_eps"]) - result["dep_tens"]
    batch_state["EQPLAS"] = state_old["EQPLAS"] + dp
    batch_state["Delta_pl"] = dp
    batch_state["last_status_code"] = result["status_code"]

    num_points = delta_eps6_batch.shape[0]
    batch_state["C_ep"] = batch_state["params"]["C0"].unsqueeze(0).repeat(num_points, 1, 1).clone()
    batch_state["C_ep_ps"] = batch_state["params"]["C0_inplane"].unsqueeze(0).repeat(num_points, 1, 1).clone()

    plastic_mask = result["status_code"] == 1
    if torch.any(plastic_mask):
        x_plastic = result["x"][plastic_mask]
        delta_plastic = delta_eps6_batch[plastic_mask]
        state_old_plastic = {
            "stress_n": state_old["stress_n"][plastic_mask],
            "stress_back": state_old["stress_back"][plastic_mask],
            "D": state_old["D"][plastic_mask],
            "eps_pl_tens": state_old["eps_pl_tens"][plastic_mask],
            "eps_el_tens": state_old["eps_el_tens"][plastic_mask],
            "EQPLAS": state_old["EQPLAS"][plastic_mask],
        }
        Cep_ps, Cep_full = plane_stress_tangent_batched(
            x_plastic, delta_plastic, state_old_plastic, batch_state["params"]
        )
        batch_state["C_ep"][plastic_mask] = Cep_full
        batch_state["C_ep_ps"][plastic_mask] = Cep_ps

    return batch_state, result


def _principal_values_sorted_desc(tensor_3x3: np.ndarray) -> np.ndarray:
    vals = np.linalg.eigvalsh(np.asarray(tensor_3x3, dtype=float))
    return vals[::-1]


def _extract_point_snapshot(batch_state: dict, point_index: int, applied_step: int) -> dict:
    stress = batch_state["stress_n"][point_index].detach().cpu().numpy()
    total_strain = (
        batch_state["eps_el_tens"][point_index] + batch_state["eps_pl_tens"][point_index]
    ).detach().cpu().numpy()
    damage = batch_state["D"][point_index].detach().cpu().numpy()
    return {
        "step": int(applied_step),
        "stress_tensor": stress,
        "strain_tensor": total_strain,
        "damage_diag": np.diag(damage).copy(),
        "stress_principal": _principal_values_sorted_desc(stress),
        "strain_principal": _principal_values_sorted_desc(total_strain),
        "EQPLAS": float(batch_state["EQPLAS"][point_index].detach().cpu().item()),
        "Delta_pl": float(batch_state["Delta_pl"][point_index].detach().cpu().item()),
        "status_code": int(batch_state["last_status_code"][point_index].detach().cpu().item()),
    }


def _simulate_batch(
    config: BatchConfig,
    *,
    resolved_device: torch.device,
    record_history: bool = False,
    history_point_index: int = 0,
) -> tuple[dict, dict, torch.Tensor, torch.Tensor, list[dict]]:
    batch_state = initialize_batch_state(config.num_points, resolved_device)
    delta_eps6_batch = torch.as_tensor(
        np.repeat(config.delta_eps6.reshape(1, 6), config.num_points, axis=0),
        dtype=DTYPE,
        device=resolved_device,
    )
    target_steps = torch.empty((config.num_points,), dtype=torch.int64, device=resolved_device)
    target_steps[:config.num_elastic_points] = config.elastic_steps
    target_steps[config.num_elastic_points:] = config.plastic_steps
    applied_steps = torch.zeros((config.num_points,), dtype=torch.int64, device=resolved_device)

    last_result = {
        "iters": torch.zeros((config.num_points,), dtype=torch.int64, device=resolved_device),
        "res_norm": torch.zeros((config.num_points,), dtype=DTYPE, device=resolved_device),
    }
    history = []
    if record_history:
        history.append(_extract_point_snapshot(batch_state, history_point_index, applied_step=0))

    if resolved_device.type == "cuda":
        torch.cuda.synchronize(resolved_device)
    batch_start = time.perf_counter()

    for _ in range(int(target_steps.max().item())):
        active_mask = applied_steps < target_steps
        if not torch.any(active_mask):
            break

        delta_active = delta_eps6_batch[active_mask]
        active_state = {
            "stress_n": batch_state["stress_n"][active_mask],
            "stress_back": batch_state["stress_back"][active_mask],
            "D": batch_state["D"][active_mask],
            "eps_pl_tens": batch_state["eps_pl_tens"][active_mask],
            "eps_el_tens": batch_state["eps_el_tens"][active_mask],
            "EQPLAS": batch_state["EQPLAS"][active_mask],
            "Delta_pl": batch_state["Delta_pl"][active_mask],
            "C_ep": batch_state["C_ep"][active_mask],
            "C_ep_ps": batch_state["C_ep_ps"][active_mask],
            "last_status_code": batch_state["last_status_code"][active_mask],
            "params": batch_state["params"],
        }

        active_state, active_result = update_material_points_gpu(active_state, delta_active)
        batch_state["stress_n"][active_mask] = active_state["stress_n"]
        batch_state["stress_back"][active_mask] = active_state["stress_back"]
        batch_state["D"][active_mask] = active_state["D"]
        batch_state["eps_pl_tens"][active_mask] = active_state["eps_pl_tens"]
        batch_state["eps_el_tens"][active_mask] = active_state["eps_el_tens"]
        batch_state["EQPLAS"][active_mask] = active_state["EQPLAS"]
        batch_state["Delta_pl"][active_mask] = active_state["Delta_pl"]
        batch_state["C_ep"][active_mask] = active_state["C_ep"]
        batch_state["C_ep_ps"][active_mask] = active_state["C_ep_ps"]
        batch_state["last_status_code"][active_mask] = active_state["last_status_code"]
        last_result["iters"][active_mask] = active_result["iters"]
        last_result["res_norm"][active_mask] = active_result["res_norm"]
        applied_steps[active_mask] += 1

        if record_history:
            history.append(
                _extract_point_snapshot(
                    batch_state,
                    history_point_index,
                    applied_step=int(applied_steps[history_point_index].detach().cpu().item()),
                )
            )

    if resolved_device.type == "cuda":
        torch.cuda.synchronize(resolved_device)
    batch_time_seconds = time.perf_counter() - batch_start

    last_result["batch_time_seconds"] = batch_time_seconds
    return batch_state, last_result, applied_steps, delta_eps6_batch, history


def _results_to_numpy(batch_state: dict, result: dict, applied_steps: torch.Tensor, delta_eps6: torch.Tensor) -> dict:
    return {
        "stress_n": batch_state["stress_n"].detach().cpu().numpy(),
        "stress_back": batch_state["stress_back"].detach().cpu().numpy(),
        "damage": batch_state["D"].detach().cpu().numpy(),
        "eqplas": batch_state["EQPLAS"].detach().cpu().numpy(),
        "delta_pl": batch_state["Delta_pl"].detach().cpu().numpy(),
        "C_ep": batch_state["C_ep"].detach().cpu().numpy(),
        "C_ep_ps": batch_state["C_ep_ps"].detach().cpu().numpy(),
        "status_code": batch_state["last_status_code"].detach().cpu().numpy(),
        "sigma33": batch_state["stress_n"][:, 2, 2].detach().cpu().numpy(),
        "applied_steps": applied_steps.detach().cpu().numpy(),
        "delta_eps6": delta_eps6.detach().cpu().numpy(),
        "iters": result["iters"].detach().cpu().numpy(),
        "res_norm": result["res_norm"].detach().cpu().numpy(),
    }


def _sequential_reference(*, target_steps: np.ndarray, delta_eps6: np.ndarray) -> dict:
    num_points = len(target_steps)
    device = torch.device("cpu")
    points = [initialize_batch_state(1, device) for _ in range(num_points)]
    delta = torch.as_tensor(np.asarray(delta_eps6, dtype=float).reshape(1, 6), dtype=DTYPE, device=device)
    statuses = np.full((num_points,), -1, dtype=int)
    stress = np.zeros((num_points, 3, 3), dtype=float)
    damage = np.zeros((num_points, 3, 3), dtype=float)
    eqplas = np.zeros((num_points,), dtype=float)
    delta_pl = np.zeros((num_points,), dtype=float)
    C_ep = np.zeros((num_points, 6, 6), dtype=float)
    C_ep_ps = np.zeros((num_points, 3, 3), dtype=float)
    sigma33 = np.zeros((num_points,), dtype=float)

    for point_idx in range(num_points):
        result = {"status_code": torch.tensor([-1], dtype=torch.int64)}
        for _ in range(int(target_steps[point_idx])):
            points[point_idx], result = update_material_points_gpu(points[point_idx], delta)
        statuses[point_idx] = int(result["status_code"][0].detach().cpu().item())
        point_np = _single_point_state_to_numpy(points[point_idx])
        stress[point_idx] = point_np["stress_n"]
        damage[point_idx] = point_np["D"]
        eqplas[point_idx] = point_np["EQPLAS"]
        delta_pl[point_idx] = point_np["Delta_pl"]
        C_ep[point_idx] = point_np["C_ep"]
        C_ep_ps[point_idx] = point_np["C_ep_ps"]
        sigma33[point_idx] = stress[point_idx][2, 2]

    return {
        "status_code": statuses,
        "stress_n": stress,
        "damage": damage,
        "eqplas": eqplas,
        "delta_pl": delta_pl,
        "C_ep": C_ep,
        "C_ep_ps": C_ep_ps,
        "sigma33": sigma33,
    }


def _allclose_group(arr: np.ndarray, indices: np.ndarray) -> bool:
    if len(indices) <= 1:
        return True
    ref = arr[indices[0]]
    return bool(all(np.allclose(arr[idx], ref, rtol=COMPARE_RTOL, atol=COMPARE_ATOL) for idx in indices[1:]))


def _build_summary(config: BatchConfig, batch_np: dict, reference: dict, device: torch.device) -> dict:
    elastic_indices = np.arange(config.num_elastic_points, dtype=int)
    plastic_indices = np.arange(config.num_elastic_points, config.num_points, dtype=int)
    statuses = batch_np["status_code"]
    stress = batch_np["stress_n"]
    damage = batch_np["damage"]
    damage_diag = np.diagonal(damage, axis1=1, axis2=2)
    eqplas = batch_np["eqplas"]
    delta_pl = batch_np["delta_pl"]
    sigma33 = batch_np["sigma33"]

    batch_vs_reference = {
        "status_code": bool(np.array_equal(statuses, reference["status_code"])),
        "stress_n": bool(np.allclose(stress, reference["stress_n"], rtol=COMPARE_RTOL, atol=COMPARE_ATOL)),
        "damage": bool(np.allclose(damage, reference["damage"], rtol=COMPARE_RTOL, atol=COMPARE_ATOL)),
        "eqplas": bool(np.allclose(eqplas, reference["eqplas"], rtol=COMPARE_RTOL, atol=COMPARE_ATOL)),
        "delta_pl": bool(np.allclose(delta_pl, reference["delta_pl"], rtol=COMPARE_RTOL, atol=COMPARE_ATOL)),
        "C_ep": bool(np.allclose(batch_np["C_ep"], reference["C_ep"], rtol=COMPARE_RTOL, atol=COMPARE_ATOL)),
        "C_ep_ps": bool(np.allclose(batch_np["C_ep_ps"], reference["C_ep_ps"], rtol=COMPARE_RTOL, atol=COMPARE_ATOL)),
        "sigma33": bool(np.allclose(sigma33, reference["sigma33"], rtol=COMPARE_RTOL, atol=COMPARE_ATOL)),
    }

    checks = {
        "status_split": bool(np.all(statuses[elastic_indices] == 0) and np.all(statuses[plastic_indices] == 1)),
        "elastic_eqplas_zero": bool(np.all(np.abs(eqplas[elastic_indices]) <= EQPLAS_ZERO_TOL)),
        "elastic_delta_pl_zero": bool(np.all(np.abs(delta_pl[elastic_indices]) <= DP_ZERO_TOL)),
        "plastic_delta_pl_positive": bool(np.all(delta_pl[plastic_indices] > DP_ZERO_TOL)),
        "plastic_eqplas_positive": bool(np.all(eqplas[plastic_indices] > EQPLAS_ZERO_TOL)),
        "plane_stress": bool(np.all(np.abs(sigma33) <= SIGMA33_TOL)),
        "finite_stress": bool(np.all(np.isfinite(stress))),
        "finite_damage": bool(np.all(np.isfinite(damage))),
        "finite_eqplas": bool(np.all(np.isfinite(eqplas))),
        "elastic_group_match": bool(
            _allclose_group(stress, elastic_indices)
            and _allclose_group(eqplas, elastic_indices)
            and _allclose_group(delta_pl, elastic_indices)
            and _allclose_group(damage_diag, elastic_indices)
        ),
        "plastic_group_match": bool(
            _allclose_group(stress, plastic_indices)
            and _allclose_group(eqplas, plastic_indices)
            and _allclose_group(delta_pl, plastic_indices)
            and _allclose_group(damage_diag, plastic_indices)
        ),
        "batch_matches_sequential_reference": bool(all(batch_vs_reference.values())),
    }

    per_point = []
    for idx in range(config.num_points):
        per_point.append(
            {
                "index": idx,
                "group": "elastic" if idx < config.num_elastic_points else "plastic",
                "status": "elastic" if statuses[idx] == 0 else "plastic" if statuses[idx] == 1 else "unknown",
                "applied_steps": int(batch_np["applied_steps"][idx]),
                "EQPLAS": float(eqplas[idx]),
                "Delta_pl": float(delta_pl[idx]),
                "sigma33": float(sigma33[idx]),
                "iters": int(batch_np["iters"][idx]),
                "res_norm": float(batch_np["res_norm"][idx]),
                "stress_voigt": np.asarray(tens_to_voigt_np(stress[idx]), dtype=float).tolist(),
                "damage_diag": np.asarray(damage_diag[idx], dtype=float).tolist(),
                "C_ep_ps": np.asarray(batch_np["C_ep_ps"][idx], dtype=float).tolist(),
            }
        )

    return {
        "config": {
            "num_points": config.num_points,
            "num_elastic_points": config.num_elastic_points,
            "num_plastic_points": config.num_plastic_points,
            "elastic_steps": config.elastic_steps,
            "plastic_steps": config.plastic_steps,
            "device": str(device),
            "delta_eps6": np.asarray(batch_np["delta_eps6"][0], dtype=float).tolist(),
            "auto_search_increment": bool(config.auto_search_increment),
        },
        "timing": {
            "batch_time_seconds": float(batch_np["batch_time_seconds"]),
            "sequential_time_seconds": float(batch_np["sequential_time_seconds"]),
            "speedup_ratio": float(batch_np["speedup_ratio"]),
        },
        "counts": {
            "elastic": int(np.sum(statuses == 0)),
            "plastic": int(np.sum(statuses == 1)),
            "elastic_indices": elastic_indices.tolist(),
            "plastic_indices": plastic_indices.tolist(),
            "intended_split_passed": bool(checks["status_split"]),
        },
        "checks": checks,
        "batch_vs_reference": batch_vs_reference,
        "per_point": per_point,
        "accepted": bool(all(checks.values())),
    }


def run_multi_gauss_points(
    *,
    num_points: int = 20,
    num_elastic_points: int = 10,
    num_plastic_points: int = 10,
    elastic_steps: int,
    plastic_steps: int,
    delta_eps6: np.ndarray | None = None,
    device: str | None = None,
    allow_cpu_fallback: bool = False,
    auto_search_increment: bool = False,
) -> dict:
    if num_elastic_points + num_plastic_points != num_points:
        raise ValueError("num_elastic_points + num_plastic_points must equal num_points")
    if plastic_steps <= elastic_steps:
        raise ValueError("plastic_steps must be greater than elastic_steps")

    config = BatchConfig(
        num_points=num_points,
        num_elastic_points=num_elastic_points,
        num_plastic_points=num_plastic_points,
        elastic_steps=elastic_steps,
        plastic_steps=plastic_steps,
        delta_eps6=None if delta_eps6 is None else np.asarray(delta_eps6, dtype=float).reshape(6),
        device=device,
        allow_cpu_fallback=allow_cpu_fallback,
        auto_search_increment=auto_search_increment,
    )
    resolved_device = resolve_device(device=device, allow_cpu_fallback=allow_cpu_fallback)
    if config.delta_eps6 is None:
        if not auto_search_increment:
            raise ValueError("delta_eps6 must be provided unless auto_search_increment=True")
        config.delta_eps6 = find_common_increment_for_split(elastic_steps, plastic_steps)

    batch_state, last_result, applied_steps, delta_eps6_batch, _ = _simulate_batch(
        config,
        resolved_device=resolved_device,
        record_history=False,
    )
    batch_time_seconds = float(last_result["batch_time_seconds"])

    batch_np = _results_to_numpy(batch_state, last_result, applied_steps, delta_eps6_batch)
    sequential_start = time.perf_counter()
    target_steps_np = np.empty((config.num_points,), dtype=int)
    target_steps_np[:config.num_elastic_points] = config.elastic_steps
    target_steps_np[config.num_elastic_points:] = config.plastic_steps
    reference = _sequential_reference(
        target_steps=target_steps_np,
        delta_eps6=np.asarray(config.delta_eps6, dtype=float),
    )
    sequential_time_seconds = time.perf_counter() - sequential_start
    speedup_ratio = (
        sequential_time_seconds / batch_time_seconds
        if batch_time_seconds > 0.0
        else float("inf")
    )
    batch_np["batch_time_seconds"] = batch_time_seconds
    batch_np["sequential_time_seconds"] = sequential_time_seconds
    batch_np["speedup_ratio"] = speedup_ratio
    return _build_summary(config, batch_np, reference, resolved_device)


def plot_principal_stress_strain_curve(
    *,
    num_points: int = 20,
    num_elastic_points: int = 10,
    num_plastic_points: int = 10,
    elastic_steps: int,
    plastic_steps: int,
    delta_eps6: np.ndarray | None = None,
    device: str | None = None,
    allow_cpu_fallback: bool = False,
    auto_search_increment: bool = False,
    point_index: int = 0,
    out_path: str | None = None,
) -> dict:
    _set_runtime_env()
    config = BatchConfig(
        num_points=num_points,
        num_elastic_points=num_elastic_points,
        num_plastic_points=num_plastic_points,
        elastic_steps=elastic_steps,
        plastic_steps=plastic_steps,
        delta_eps6=None if delta_eps6 is None else np.asarray(delta_eps6, dtype=float).reshape(6),
        device=device,
        allow_cpu_fallback=allow_cpu_fallback,
        auto_search_increment=auto_search_increment,
    )
    resolved_device = resolve_device(device=device, allow_cpu_fallback=allow_cpu_fallback)
    if point_index < 0 or point_index >= config.num_points:
        raise ValueError("point_index is out of range")
    if config.delta_eps6 is None:
        if not auto_search_increment:
            raise ValueError("delta_eps6 must be provided unless auto_search_increment=True")
        config.delta_eps6 = find_common_increment_for_split(elastic_steps, plastic_steps)

    batch_state, last_result, applied_steps, delta_eps6_batch, history = _simulate_batch(
        config,
        resolved_device=resolved_device,
        record_history=True,
        history_point_index=point_index,
    )
    if out_path is None:
        out_path = str(ROOT / "implicit_scheme" / "implicit_anisotropic_damage" / "v6_principal_stress_strain_curve.png")

    principal_strain = np.asarray([entry["strain_principal"] for entry in history], dtype=float)
    principal_stress = np.asarray([entry["stress_principal"] for entry in history], dtype=float)
    steps = np.asarray([entry["step"] for entry in history], dtype=int)

    fig, ax = plt.subplots(figsize=(8, 6))
    labels = ["Principal 1", "Principal 2", "Principal 3"]
    colors = ["tab:red", "tab:blue", "tab:green"]
    for i in range(3):
        ax.plot(principal_strain[:, i], principal_stress[:, i], color=colors[i], linewidth=2.0, label=labels[i])

    ax.set_xlabel("Principal Strain")
    ax.set_ylabel("Principal Stress")
    ax.set_title(f"Principal Stress-Strain Response (Point {point_index})")
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)

    return {
        "plot_path": out_path,
        "point_index": point_index,
        "device": str(resolved_device),
        "steps_recorded": steps.tolist(),
        "principal_strain_history": principal_strain.tolist(),
        "principal_stress_history": principal_stress.tolist(),
        "final_status_code": int(batch_state["last_status_code"][point_index].detach().cpu().item()),
        "final_EQPLAS": float(batch_state["EQPLAS"][point_index].detach().cpu().item()),
        "batch_time_seconds": float(last_result["batch_time_seconds"]),
        "applied_steps": int(applied_steps[point_index].detach().cpu().item()),
        "delta_eps6": np.asarray(delta_eps6_batch[point_index].detach().cpu().numpy(), dtype=float).tolist(),
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the stage-1 batched GPU constitutive update harness.")
    parser.add_argument("--num-points", type=int, default=20)
    parser.add_argument("--num-elastic-points", type=int, default=10)
    parser.add_argument("--num-plastic-points", type=int, default=10)
    parser.add_argument("--elastic-steps", type=int, required=True)
    parser.add_argument("--plastic-steps", type=int, required=True)
    parser.add_argument(
        "--delta-eps6",
        type=float,
        nargs=6,
        default=None,
        metavar=("E11", "E22", "E33", "E23", "E13", "E12"),
        help="Common strain increment in Voigt form. Omit only when using --auto-search-increment.",
    )
    parser.add_argument("--device", type=str, default=None)
    parser.add_argument("--allow-cpu-fallback", action="store_true")
    parser.add_argument("--auto-search-increment", action="store_true")
    parser.add_argument("--plot-principal", action="store_true")
    parser.add_argument("--plot-point-index", type=int, default=0)
    parser.add_argument("--plot-path", type=str, default=None)
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    if args.plot_principal:
        result = plot_principal_stress_strain_curve(
            num_points=args.num_points,
            num_elastic_points=args.num_elastic_points,
            num_plastic_points=args.num_plastic_points,
            elastic_steps=args.elastic_steps,
            plastic_steps=args.plastic_steps,
            delta_eps6=None if args.delta_eps6 is None else np.asarray(args.delta_eps6, dtype=float),
            device=args.device,
            allow_cpu_fallback=args.allow_cpu_fallback,
            auto_search_increment=args.auto_search_increment,
            point_index=args.plot_point_index,
            out_path=args.plot_path,
        )
        print(json.dumps(result, indent=2))
        return

    summary = run_multi_gauss_points(
        num_points=args.num_points,
        num_elastic_points=args.num_elastic_points,
        num_plastic_points=args.num_plastic_points,
        elastic_steps=args.elastic_steps,
        plastic_steps=args.plastic_steps,
        delta_eps6=None if args.delta_eps6 is None else np.asarray(args.delta_eps6, dtype=float),
        device=args.device,
        allow_cpu_fallback=args.allow_cpu_fallback,
        auto_search_increment=args.auto_search_increment,
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
