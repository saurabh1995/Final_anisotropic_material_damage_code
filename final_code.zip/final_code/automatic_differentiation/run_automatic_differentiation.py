#!/usr/bin/env python3
"""Run a self-contained elastic AD/plane-stress tangent smoke test."""

from __future__ import annotations

import json
from pathlib import Path

import torch

import implicit_anisotropic_damage_ad as model


HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "ad_demo_summary.json"


def main() -> None:
    state = model.initialize_batch_state(1, torch.device("cpu"))
    delta = torch.tensor([[1e-5, -2e-6, 0.0, 0.0, 0.0, 3e-6]], dtype=model.DTYPE)
    state, result = model.update_material_points_gpu(state, delta)
    output = {
        "device": "cpu",
        "status": "elastic" if int(result["status_code"][0]) == 0 else "plastic",
        "sigma33": float(state["stress_n"][0, 2, 2]),
        "C_ep_ps": state["C_ep_ps"][0].tolist(),
    }
    OUTPUT.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
