# Automatic-Differentiation Tangent Model

`implicit_anisotropic_damage_ad.py` provides the batched implicit material
update and its automatic-differentiation consistent plane-stress tangent.
`batched_anisotropic_damage_core.py` contains the underlying batched
constitutive operations.

Run the included example from the package root:

```bash
python automatic_differentiation/run_automatic_differentiation.py
```
